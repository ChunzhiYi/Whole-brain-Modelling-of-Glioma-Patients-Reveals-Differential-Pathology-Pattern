# 脚本文件
    见目录part1_pMFM_main_full/
## 公共文件
    pMFM_basic_functions_main.py (公共功能)
    pMFM_step1_training_main.py (训练)
    pMFM_step2_validation_main.py (验证)
    pMFM_step3_test_main.py (测试，mouse不用)
## HCP便捷配置与运行脚本
    hcp_task_config.conf
    hcp_task_run.sh (结合conf配置，在终端批量运行)
    pMFM_config_hcp.py
    train_vali_test.py (可直接python运行，可带参数)
## mouse便捷配置与运行脚本
    mouse_task_config.conf
    mouse_task_run.sh (结合conf配置，在终端批量运行)
    pMFM_config_mouse.py
    pMFM_mouse_set_info.py
    train_vali.py (可直接python运行，可带参数)

# 使用方式
## 分步运行
    1. 复制pMFM_config_hcp.py或pMFM_config_mouse.py文件，并重命名为pMFM_config.py
    2. 酌情修改pMFM_config.py中的参数配置
    3. 运行pMFM_step1_training_main.py (训练)
    4. 运行pMFM_step2_validation_main.py (验证)
    5. 运行pMFM_step3_test_main.py (测试，mouse不用)
## 便捷配置并批量自动运行
### 人类HCP数据
#### 方式一：直接运行脚本
    直接在终端运行python train_vali_test.py --gpu <GPU_INDEX> --plan <PLAN_TYPE> --atlas <ATLAS> --train_seeds <TRAIN_SEEDS> --test_seeds <TEST_SEEDS>
    或
    1. 配置修改pMFM_config_hcp.py中的参数
    2. 在终端运行train_vali_test.py
#### 方式二：结合配置文件运行脚本，可在多个GPU上并行运行
    1. 简单配置修改hcp_task_config.conf中的参数，其他配置修改pMFM_config_hcp.py中的参数
    2. 在终端运行hcp_task_run.sh
### 小鼠数据
#### 方式一：直接运行脚本
    直接在终端运行python train_vali.py --gpu <GPU_INDEX> --plan <PLAN_TYPE> --group <GROUP> --fold <FOLD> --seeds <SEEDS>
    或
    1. 配置修改pMFM_config_mouse.py中的参数
    2. 在终端运行train_vali.py
#### 方式二：结合配置文件运行脚本，可在多个GPU上并行运行
    1. 简单配置修改mouse_task_config.conf中的参数，其他配置修改pMFM_config_mouse.py中的参数
    2. 在终端运行mouse_task_run.sh
