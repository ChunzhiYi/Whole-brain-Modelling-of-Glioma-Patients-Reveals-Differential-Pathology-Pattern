# /usr/bin/env python
'''
Written by Kong Xiaolu and CBIG under MIT license:
https://github.com/ThomasYeoLab/CBIG/blob/master/LICENSE.md
'''

import os
import numpy as np
import time
import torch
import pMFM_basic_functions_main as fc
from pMFM_config import system_config, validation_config, test_config, plan
import warnings


def CBIG_mfm_test_main_fusion_para(set_range=range(1,11), gpu_index=0):
    '''
    This function is to implement the testing processes of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    torch.cuda.manual_seed(1)

    # Create output folder
    input_path = system_config.output_path + validation_config.output_dir
    output_path = system_config.output_path + test_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Setting hyper-parameters
    n_set = test_config.n_set # 100
    n_dup = test_config.n_dup # 10 for average

    n_node = system_config.n_roi
    vali_raw_all = np.zeros((5 * n_node + 1 + 8, 1))

    # Read the validation results from the input folder
    print('load validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for i in set_range:
        load_file = 'random_initialization_' + str(i) + '.csv'
        load_path = os.path.join(input_path, load_file)
        xmin = fc.csv_matrix_read(load_path)
        index_mat = np.zeros((2, xmin.shape[1]))
        index_mat[0, :] = i
        index_mat[1, :] = np.arange(xmin.shape[1])
        xmin = np.concatenate((index_mat, xmin), axis=0)

        vali_raw_all = np.concatenate((vali_raw_all, xmin), axis=1)

    vali_raw_all = vali_raw_all[:, 1:]  ## (5 * n_node + 1 + 8, 5000)
    if hasattr(system_config, 'hierarchy_cost_mode') and system_config.hierarchy_cost_mode \
       and hasattr(system_config, 'select_by_hierarchy_cost') and not system_config.select_by_hierarchy_cost:
        # 使用第5行(fc_cost)和第6行(fcd_cost)的和作为排序依据
        fc_costs = vali_raw_all[5, :]  # 第5行: fc_cost
        fcd_costs = vali_raw_all[6, :]  # 第6行: fcd_cost
        combined_costs = fc_costs + fcd_costs
        vali_index = np.argsort(combined_costs)
    else:
        # 使用第7行(total_cost)作为排序依据
        vali_index = np.argsort(vali_raw_all[7, :])
    vali_sort_all = vali_raw_all[:, vali_index]

    vali_sel_num = test_config.n_solution
    print('select the top ',vali_sel_num,' validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    i = 0
    vali_sel = np.zeros((vali_raw_all.shape[0], vali_sel_num))
    p = 0
    p_set = np.zeros(vali_sel_num)
    # Select the top 10 validation results
    while i < vali_sel_num and p < vali_raw_all.shape[1]:
        corr_t = np.zeros(vali_sel_num, dtype=bool)
        corr_tr = np.zeros((vali_sel_num, 3))
        for j in range(vali_sel_num):
            w_corr = np.corrcoef(vali_sel[8:8 + n_node, j:j + 1].T,
                                 vali_sort_all[8:8 + n_node, p:p + 1].T)
            i_corr = np.corrcoef(
                vali_sel[8 + n_node:8 + 2 * n_node, j:j + 1].T,
                vali_sort_all[8 + n_node:8 + 2 * n_node, p:p + 1].T)
            s_corr = np.corrcoef(vali_sel[9 + 2 * n_node:, j:j + 1].T,
                                 vali_sort_all[9 + 2 * n_node:, p:p + 1].T)
            ## todo wI and wG can be considered, not necessary
            corr_tr[j, 0] = w_corr[0, 1]
            corr_tr[j, 1] = i_corr[0, 1]
            corr_tr[j, 2] = s_corr[0, 1]

        for k in range(vali_sel_num):
            corr_t[k] = (corr_tr[k, :] > 0.98).all()

        if not corr_t.any():
            vali_sel[:, i] = vali_sort_all[:, p]
            p_set[i] = p
            i += 1
        p += 1

    result_save = np.zeros((5 * n_node + 1 + 11, vali_sel_num))
    result_save[0:8, :] = vali_sel[0:8, :]
    result_save[11:, :] = vali_sel[8:, :]

    # Test the selected validation results
    print('test the selected validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for j in range(vali_sel_num):
        test_cost = np.zeros((3, n_set * 10))
        for k in range(10):
            arx = np.tile(vali_sel[8:, j:j + 1], [1, n_set])
            total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_test_fusion(
                arx, n_dup)
            test_cost[0, n_set * k:n_set * (k + 1)] = fc_cost
            test_cost[1, n_set * k:n_set * (k + 1)] = fcd_cost
            test_cost[2, n_set * k:n_set * (k + 1)] = total_cost
            test_file = os.path.join(output_path,
                                     'test_num_' + str(j + 1) + '.csv')
            np.savetxt(test_file, test_cost, delimiter=',')

        result_save[8, j] = np.nanmean(test_cost[0, :])
        result_save[9, j] = np.nanmean(test_cost[1, :])
        result_save[10, j] = np.nanmean(test_cost[2, :])
        print('****************  fusion para finish top ' + str(j + 1) + ' test  ****************', flush=True)
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        test_file_all = os.path.join(output_path, 'test_all.csv')
        np.savetxt(test_file_all, result_save, delimiter=',')
    print('****************  fusion para test done  ****************', flush=True)

def CBIG_mfm_test_main_fusion_heter(set_range=range(1,11), gpu_index=0):
    '''
    This function is to implement the testing processes of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    torch.cuda.manual_seed(1)

    # Create output folder
    input_path = system_config.output_path + validation_config.output_dir
    output_path = system_config.output_path + test_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Setting hyper-parameters
    n_set = test_config.n_set # 100
    n_dup = test_config.n_dup # 10 for average

    n_node = system_config.n_roi
    vali_raw_all = np.zeros((5 * n_node + 1 + 8, 1))

    # Read the validation results from the input folder
    print('load validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for i in set_range:
        load_file = 'random_initialization_' + str(i) + '.csv'
        load_path = os.path.join(input_path, load_file)
        xmin = fc.csv_matrix_read(load_path)
        index_mat = np.zeros((2, xmin.shape[1]))
        index_mat[0, :] = i
        index_mat[1, :] = np.arange(xmin.shape[1])
        xmin = np.concatenate((index_mat, xmin), axis=0)

        vali_raw_all = np.concatenate((vali_raw_all, xmin), axis=1)

    vali_raw_all = vali_raw_all[:, 1:]  ## (5 * n_node + 1 + 8, 5000)
    if hasattr(system_config, 'hierarchy_cost_mode') and system_config.hierarchy_cost_mode \
       and hasattr(system_config, 'select_by_hierarchy_cost') and not system_config.select_by_hierarchy_cost:
        # 使用第5行(fc_cost)和第6行(fcd_cost)的和作为排序依据
        fc_costs = vali_raw_all[5, :]  # 第5行: fc_cost
        fcd_costs = vali_raw_all[6, :]  # 第6行: fcd_cost
        combined_costs = fc_costs + fcd_costs
        vali_index = np.argsort(combined_costs)
    else:
        # 使用第7行(total_cost)作为排序依据
        vali_index = np.argsort(vali_raw_all[7, :])
    vali_sort_all = vali_raw_all[:, vali_index]

    vali_sel_num = test_config.n_solution
    print('select the top ',vali_sel_num,' validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    i = 0
    vali_sel = np.zeros((vali_raw_all.shape[0], vali_sel_num))
    p = 0
    p_set = np.zeros(vali_sel_num)
    # Select the top 10 validation results
    while i < vali_sel_num and p < vali_raw_all.shape[1]:
        corr_t = np.zeros(vali_sel_num, dtype=bool)
        corr_tr = np.zeros((vali_sel_num, 3))
        for j in range(vali_sel_num):
            w_corr = np.corrcoef(vali_sel[8:8 + n_node, j:j + 1].T,
                                 vali_sort_all[8:8 + n_node, p:p + 1].T)
            i_corr = np.corrcoef(
                vali_sel[8 + n_node:8 + 2 * n_node, j:j + 1].T,
                vali_sort_all[8 + n_node:8 + 2 * n_node, p:p + 1].T)
            s_corr = np.corrcoef(vali_sel[9 + 2 * n_node:, j:j + 1].T,
                                 vali_sort_all[9 + 2 * n_node:, p:p + 1].T)
            ## todo wI and wG can be considered, not necessary
            corr_tr[j, 0] = w_corr[0, 1]
            corr_tr[j, 1] = i_corr[0, 1]
            corr_tr[j, 2] = s_corr[0, 1]

        for k in range(vali_sel_num):
            corr_t[k] = (corr_tr[k, :] > 0.98).all()

        if not corr_t.any():
            vali_sel[:, i] = vali_sort_all[:, p]
            p_set[i] = p
            i += 1
        p += 1

    result_save = np.zeros((5 * n_node + 1 + 11, vali_sel_num))
    result_save[0:8, :] = vali_sel[0:8, :]
    result_save[11:, :] = vali_sel[8:, :]

    # Test the selected validation results
    print('test the selected validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for j in range(vali_sel_num):
        test_cost = np.zeros((3, n_set * 10))
        for k in range(10):
            arx = np.tile(vali_sel[8:, j:j + 1], [1, n_set])
            total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_test_fusion(
                arx, n_dup)
            test_cost[0, n_set * k:n_set * (k + 1)] = fc_cost
            test_cost[1, n_set * k:n_set * (k + 1)] = fcd_cost
            test_cost[2, n_set * k:n_set * (k + 1)] = total_cost
            test_file = os.path.join(output_path,
                                     'test_num_' + str(j + 1) + '.csv')
            np.savetxt(test_file, test_cost, delimiter=',')

        result_save[8, j] = np.nanmean(test_cost[0, :])
        result_save[9, j] = np.nanmean(test_cost[1, :])
        result_save[10, j] = np.nanmean(test_cost[2, :])
        print('****************  fusion heter finish top ' + str(j + 1) + ' test  ****************', flush=True)
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        test_file_all = os.path.join(output_path, 'test_all.csv')
        np.savetxt(test_file_all, result_save, delimiter=',')
    print('****************  fusion heter test done  ****************', flush=True)

def CBIG_mfm_test_main_neuro_para(set_range=range(1,11), gpu_index=0):
    '''
    This function is to implement the testing processes of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    torch.cuda.manual_seed(1)

    # Create output folder
    input_path = system_config.output_path + validation_config.output_dir
    output_path = system_config.output_path + test_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Setting hyper-parameters
    n_set = test_config.n_set # 100
    n_dup = test_config.n_dup # 10 for average
    ## n_set * n_dup = number of times each parameter set is simulated

    n_node = system_config.n_roi
    vali_raw_all = np.zeros((4 * n_node + 1 + 8, 1))

    # Read the validation results from the input folder
    print('load validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for i in set_range:
        load_file = 'random_initialization_' + str(i) + '.csv'
        load_path = os.path.join(input_path, load_file)
        xmin = fc.csv_matrix_read(load_path)
        index_mat = np.zeros((2, xmin.shape[1]))
        index_mat[0, :] = i     ## set i
        index_mat[1, :] = np.arange(xmin.shape[1])  ## index in set i
        xmin = np.concatenate((index_mat, xmin), axis=0)

        vali_raw_all = np.concatenate((vali_raw_all, xmin), axis=1)

    vali_raw_all = vali_raw_all[:, 1:]  ## (4 * n_node + 1 + 8, 5000)
    if hasattr(system_config, 'hierarchy_cost_mode') and system_config.hierarchy_cost_mode \
       and hasattr(system_config, 'select_by_hierarchy_cost') and not system_config.select_by_hierarchy_cost:
        # 使用第5行(fc_cost)和第6行(fcd_cost)的和作为排序依据
        fc_costs = vali_raw_all[5, :]  # 第5行: fc_cost
        fcd_costs = vali_raw_all[6, :]  # 第6行: fcd_cost
        combined_costs = fc_costs + fcd_costs
        vali_index = np.argsort(combined_costs)
    else:
        # 使用第7行(total_cost)作为排序依据
        vali_index = np.argsort(vali_raw_all[7, :])
    vali_sort_all = vali_raw_all[:, vali_index]

    vali_sel_num = test_config.n_solution
    print('select the top ',vali_sel_num,' validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    i = 0
    vali_sel = np.zeros((vali_raw_all.shape[0], vali_sel_num))
    p = 0
    p_set = np.zeros(vali_sel_num)
    # Select the top 10 validation results
    while i < vali_sel_num and p < vali_raw_all.shape[1]:
        corr_t = np.zeros(vali_sel_num, dtype=bool)
        corr_tr = np.zeros((vali_sel_num, 3))
        for j in range(vali_sel_num):
            w_corr = np.corrcoef(vali_sel[8:8 + n_node, j:j + 1].T,
                                 vali_sort_all[8:8 + n_node, p:p + 1].T)
            i_corr = np.corrcoef(
                vali_sel[8 + n_node:8 + 2 * n_node, j:j + 1].T,
                vali_sort_all[8 + n_node:8 + 2 * n_node, p:p + 1].T)
            s_corr = np.corrcoef(vali_sel[9 + 2 * n_node:, j:j + 1].T,
                                 vali_sort_all[9 + 2 * n_node:, p:p + 1].T)
            ## todo wI and wG can be considered, not necessary
            corr_tr[j, 0] = w_corr[0, 1]
            corr_tr[j, 1] = i_corr[0, 1]
            corr_tr[j, 2] = s_corr[0, 1]

        for k in range(vali_sel_num):
            corr_t[k] = (corr_tr[k, :] > 0.98).all()

        if not corr_t.any():
            vali_sel[:, i] = vali_sort_all[:, p]
            p_set[i] = p
            i += 1
        p += 1

    result_save = np.zeros((4 * n_node + 1 + 11, vali_sel_num))
    result_save[0:8, :] = vali_sel[0:8, :]
    result_save[11:, :] = vali_sel[8:, :]

    # Test the selected validation results
    print('test the selected validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for j in range(vali_sel_num):
        test_cost = np.zeros((3, n_set * 10))
        for k in range(10):
            arx = np.tile(vali_sel[8:, j:j + 1], [1, n_set])    ## each set copy 100 * 10 loop
            total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_test_neuro(
                arx, n_dup)
            test_cost[0, n_set * k:n_set * (k + 1)] = fc_cost
            test_cost[1, n_set * k:n_set * (k + 1)] = fcd_cost
            test_cost[2, n_set * k:n_set * (k + 1)] = total_cost
            test_file = os.path.join(output_path,
                                     'test_num_' + str(j + 1) + '.csv')
            np.savetxt(test_file, test_cost, delimiter=',')

        result_save[8, j] = np.nanmean(test_cost[0, :])
        result_save[9, j] = np.nanmean(test_cost[1, :])
        result_save[10, j] = np.nanmean(test_cost[2, :])
        print('****************  neuro para finish top ' + str(j + 1) + ' test  ****************', flush=True)
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        test_file_all = os.path.join(output_path, 'test_all.csv')
        np.savetxt(test_file_all, result_save, delimiter=',')
    print('****************  neuro para test done  ****************', flush=True)

def CBIG_mfm_test_main_neuro_heter(set_range=range(1,11), gpu_index=0):
    '''
    This function is to implement the testing processes of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    torch.cuda.manual_seed(1)

    # Create output folder
    input_path = system_config.output_path + validation_config.output_dir
    output_path = system_config.output_path + test_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Setting hyper-parameters
    n_set = test_config.n_set # 100
    n_dup = test_config.n_dup # 10 for average
    ## n_set * n_dup = number of times each parameter set is simulated

    n_node = system_config.n_roi
    vali_raw_all = np.zeros((4 * n_node + 1 + 8, 1))

    # Read the validation results from the input folder
    print('load validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for i in set_range:
        load_file = 'random_initialization_' + str(i) + '.csv'
        load_path = os.path.join(input_path, load_file)
        xmin = fc.csv_matrix_read(load_path)
        index_mat = np.zeros((2, xmin.shape[1]))
        index_mat[0, :] = i     ## set i
        index_mat[1, :] = np.arange(xmin.shape[1])  ## index in set i
        xmin = np.concatenate((index_mat, xmin), axis=0)

        vali_raw_all = np.concatenate((vali_raw_all, xmin), axis=1)

    vali_raw_all = vali_raw_all[:, 1:]  ## (4 * n_node + 1 + 8, 5000)
    if hasattr(system_config, 'hierarchy_cost_mode') and system_config.hierarchy_cost_mode \
       and hasattr(system_config, 'select_by_hierarchy_cost') and not system_config.select_by_hierarchy_cost:
        # 使用第5行(fc_cost)和第6行(fcd_cost)的和作为排序依据
        fc_costs = vali_raw_all[5, :]  # 第5行: fc_cost
        fcd_costs = vali_raw_all[6, :]  # 第6行: fcd_cost
        combined_costs = fc_costs + fcd_costs
        vali_index = np.argsort(combined_costs)
    else:
        # 使用第7行(total_cost)作为排序依据
        vali_index = np.argsort(vali_raw_all[7, :])
    vali_sort_all = vali_raw_all[:, vali_index]

    vali_sel_num = test_config.n_solution
    print('select the top ',vali_sel_num,' validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    i = 0
    vali_sel = np.zeros((vali_raw_all.shape[0], vali_sel_num))
    p = 0
    p_set = np.zeros(vali_sel_num)
    # Select the top 10 validation results
    while i < vali_sel_num and p < vali_raw_all.shape[1]:
        corr_t = np.zeros(vali_sel_num, dtype=bool)
        corr_tr = np.zeros((vali_sel_num, 3))
        for j in range(vali_sel_num):
            w_corr = np.corrcoef(vali_sel[8:8 + n_node, j:j + 1].T,
                                 vali_sort_all[8:8 + n_node, p:p + 1].T)
            i_corr = np.corrcoef(
                vali_sel[8 + n_node:8 + 2 * n_node, j:j + 1].T,
                vali_sort_all[8 + n_node:8 + 2 * n_node, p:p + 1].T)
            s_corr = np.corrcoef(vali_sel[9 + 2 * n_node:, j:j + 1].T,
                                 vali_sort_all[9 + 2 * n_node:, p:p + 1].T)
            ## todo wI and wG can be considered, not necessary
            corr_tr[j, 0] = w_corr[0, 1]
            corr_tr[j, 1] = i_corr[0, 1]
            corr_tr[j, 2] = s_corr[0, 1]

        for k in range(vali_sel_num):
            corr_t[k] = (corr_tr[k, :] > 0.98).all()

        if not corr_t.any():
            vali_sel[:, i] = vali_sort_all[:, p]
            p_set[i] = p
            i += 1
        p += 1

    result_save = np.zeros((4 * n_node + 1 + 11, vali_sel_num))
    result_save[0:8, :] = vali_sel[0:8, :]
    result_save[11:, :] = vali_sel[8:, :]

    # Test the selected validation results
    print('test the selected validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for j in range(vali_sel_num):
        test_cost = np.zeros((3, n_set * 10))
        for k in range(10):
            arx = np.tile(vali_sel[8:, j:j + 1], [1, n_set])    ## each set copy 100 * 10 loop
            total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_test_neuro(
                arx, n_dup)
            test_cost[0, n_set * k:n_set * (k + 1)] = fc_cost
            test_cost[1, n_set * k:n_set * (k + 1)] = fcd_cost
            test_cost[2, n_set * k:n_set * (k + 1)] = total_cost
            test_file = os.path.join(output_path,
                                     'test_num_' + str(j + 1) + '.csv')
            np.savetxt(test_file, test_cost, delimiter=',')

        result_save[8, j] = np.nanmean(test_cost[0, :])
        result_save[9, j] = np.nanmean(test_cost[1, :])
        result_save[10, j] = np.nanmean(test_cost[2, :])
        print('****************  neuro heter finish top ' + str(j + 1) + ' test  ****************', flush=True)
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        test_file_all = os.path.join(output_path, 'test_all.csv')
        np.savetxt(test_file_all, result_save, delimiter=',')
    print('****************  neuro heter test done  ****************', flush=True)

def CBIG_mfm_test_main_fusion_para_wg_heter(set_range=range(1,11), gpu_index=0):
    '''
    This function is to implement the testing processes of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    torch.cuda.manual_seed(1)

    # Create output folder
    input_path = system_config.output_path + validation_config.output_dir
    output_path = system_config.output_path + test_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Setting hyper-parameters
    n_set = test_config.n_set # 100
    n_dup = test_config.n_dup # 10 for average

    n_node = system_config.n_roi
    vali_raw_all = np.zeros((5 * n_node + 1 + 8, 1))

    # Read the validation results from the input folder
    print('load validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for i in set_range:
        load_file = 'random_initialization_' + str(i) + '.csv'
        load_path = os.path.join(input_path, load_file)
        xmin = fc.csv_matrix_read(load_path)
        index_mat = np.zeros((2, xmin.shape[1]))
        index_mat[0, :] = i
        index_mat[1, :] = np.arange(xmin.shape[1])
        xmin = np.concatenate((index_mat, xmin), axis=0)

        vali_raw_all = np.concatenate((vali_raw_all, xmin), axis=1)

    vali_raw_all = vali_raw_all[:, 1:]  ## (5 * n_node + 1 + 8, 5000)
    if hasattr(system_config, 'hierarchy_cost_mode') and system_config.hierarchy_cost_mode \
       and hasattr(system_config, 'select_by_hierarchy_cost') and not system_config.select_by_hierarchy_cost:
        # 使用第5行(fc_cost)和第6行(fcd_cost)的和作为排序依据
        fc_costs = vali_raw_all[5, :]  # 第5行: fc_cost
        fcd_costs = vali_raw_all[6, :]  # 第6行: fcd_cost
        combined_costs = fc_costs + fcd_costs
        vali_index = np.argsort(combined_costs)
    else:
        # 使用第7行(total_cost)作为排序依据
        vali_index = np.argsort(vali_raw_all[7, :])
    vali_sort_all = vali_raw_all[:, vali_index]

    vali_sel_num = test_config.n_solution
    print('select the top ',vali_sel_num,' validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    i = 0
    vali_sel = np.zeros((vali_raw_all.shape[0], vali_sel_num))
    p = 0
    p_set = np.zeros(vali_sel_num)
    # Select the top 10 validation results
    while i < vali_sel_num and p < vali_raw_all.shape[1]:
        corr_t = np.zeros(vali_sel_num, dtype=bool)
        corr_tr = np.zeros((vali_sel_num, 3))
        for j in range(vali_sel_num):
            w_corr = np.corrcoef(vali_sel[8:8 + n_node, j:j + 1].T,
                                 vali_sort_all[8:8 + n_node, p:p + 1].T)
            i_corr = np.corrcoef(
                vali_sel[8 + n_node:8 + 2 * n_node, j:j + 1].T,
                vali_sort_all[8 + n_node:8 + 2 * n_node, p:p + 1].T)
            s_corr = np.corrcoef(vali_sel[9 + 2 * n_node:, j:j + 1].T,
                                 vali_sort_all[9 + 2 * n_node:, p:p + 1].T)
            ## todo wI and wG can be considered, not necessary
            corr_tr[j, 0] = w_corr[0, 1]
            corr_tr[j, 1] = i_corr[0, 1]
            corr_tr[j, 2] = s_corr[0, 1]

        for k in range(vali_sel_num):
            corr_t[k] = (corr_tr[k, :] > 0.98).all()

        if not corr_t.any():
            vali_sel[:, i] = vali_sort_all[:, p]
            p_set[i] = p
            i += 1
        p += 1

    result_save = np.zeros((5 * n_node + 1 + 11, vali_sel_num))
    result_save[0:8, :] = vali_sel[0:8, :]
    result_save[11:, :] = vali_sel[8:, :]

    # Test the selected validation results
    print('test the selected validation results ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    for j in range(vali_sel_num):
        test_cost = np.zeros((3, n_set * 10))
        for k in range(10):
            arx = np.tile(vali_sel[8:, j:j + 1], [1, n_set])
            total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_test_fusion(
                arx, n_dup)
            test_cost[0, n_set * k:n_set * (k + 1)] = fc_cost
            test_cost[1, n_set * k:n_set * (k + 1)] = fcd_cost
            test_cost[2, n_set * k:n_set * (k + 1)] = total_cost
            test_file = os.path.join(output_path,
                                     'test_num_' + str(j + 1) + '.csv')
            np.savetxt(test_file, test_cost, delimiter=',')

        result_save[8, j] = np.nanmean(test_cost[0, :])
        result_save[9, j] = np.nanmean(test_cost[1, :])
        result_save[10, j] = np.nanmean(test_cost[2, :])
        print('****************  fusion para wg_heter finish top ' + str(j + 1) + ' test  ****************', flush=True)
        print(time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        test_file_all = os.path.join(output_path, 'test_all.csv')
        np.savetxt(test_file_all, result_save, delimiter=',')
    print('****************  fusion para wg_heter test done  ****************', flush=True)

def test_main(plan_type):
    cases = {
    plan.neuro_heter: CBIG_mfm_test_main_neuro_heter,
    plan.neuro_para: CBIG_mfm_test_main_neuro_para,
    plan.fusion_heter: CBIG_mfm_test_main_fusion_heter,
    plan.fusion_para: CBIG_mfm_test_main_fusion_para,
    plan.fusion_para_wg_heter: CBIG_mfm_test_main_fusion_para_wg_heter,
    }
    return cases.get(plan_type, plan.fusion_heter)

if __name__ == '__main__':
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    test_main(system_config.plan_type)(set_range=system_config.test_random_seeds)

