# /usr/bin/env python
'''
Written by Kong Xiaolu and CBIG under MIT license:
https://github.com/ThomasYeoLab/CBIG/blob/master/LICENSE.md
'''

import os
import numpy as np
import time
import torch
import pMFM_basic_functions_main as fc
from pMFM_config import system_config, training_config, plan
import warnings


def get_init(myelin_data, gradient_data, highest_order, init_para):
    '''
    This function is implemented to calculate the initial parametrized coefficients
    '''

    # 获取myelin_data的节点数
    n_node = myelin_data.shape[0]
    # 初始化amatrix和bmatrix，大小为(n_node, highest_order + 1)
    amatrix = np.zeros((n_node, highest_order + 1))
    bmatrix = np.zeros((n_node, highest_order + 1))
    # 遍历highest_order + 1次
    for i in range(highest_order + 1):  ## 阶0到highest_order（包括highest_order）
        # 将myelin_data的i次方赋值给amatrix的第i列
        amatrix[:, i] = myelin_data**(i)
        # 将gradient_data的i次方赋值给bmatrix的第i列
        bmatrix[:, i] = gradient_data**(i)
    # 将amatrix和bmatrix的1到highest_order + 1列拼接成cmatrix
    cmatrix = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1])) ## 与init_para无关
    ## cmatrix维度为(n_node, highest_order + 1 + highest_order)，即(n_node, highest_order * 2 + 1)
    ## 内容为1，myelin_data的i次方，gradient_data的i次方（i从1到highest_order）

    # 计算para
    para = np.linalg.inv(cmatrix.T @ cmatrix) @ cmatrix.T @ init_para
    ## 最小二乘法中参数的最优估计，即在多项式回归中通过最小化残差平方和得到的最佳系数
    ## linalg线代模块，inv求逆矩阵，@矩阵乘法。init_para维度为(n_node, 1)
    ## para维度为(2h+1, 1)，参数abc。cmatrix才是多项式自变量X观测值，init_para为多项式因变量Y
    # 返回para和cmatrix
    return para, cmatrix


def CBIG_mfm_optimization_main_fusion_para(gpu_index=0, random_seed=1): ## 神经胶质，参数化
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Fusion Para', flush=True)
    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Initializing input parameters
    highest_order = 1
    N_para = 2 * highest_order + 1
    N = 5 * (N_para) + 1 ## 2*highest_order + 1，1是0阶，2是myelin和grad各1阶。“阶”来自多项式
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0] ## 维度(68,1) 
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]
    dim = 5 * n_node + 1

    search_range = np.zeros((dim, 2))   ## 初始化范围，实数闭区间
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI,wG
    init_para = rng.uniform(0, 1, dim) * (  ## 维度(dim,1)
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]   ## 初始化为范围内随机实数，闭区间
    start_point_w, template_mat = get_init(myelin_data, gradient_data,  ## 
                                           highest_order, 
                                           init_para[0:n_node])
    start_point_i, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order,
                                           init_para[n_node:n_node * 2])
    start_point_sigma, template_mat = get_init(myelin_data, gradient_data,
                                               highest_order,
                                               init_para[n_node * 2 + 1:n_node * 3 + 1])
    start_point_w_I, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order, 
                                           init_para[n_node * 3 + 1:n_node * 4 + 1])
    start_point_w_G, template_mat = get_init(myelin_data, gradient_data,
                                             highest_order, 
                                             init_para[n_node * 4 + 1:dim])
    ## start_point 维度为(2 * highest_order + 1, 1)。训练用的待拟合参数
    ## template_mat = cmatrix 线性多项式的项，用于从训练参数abc生成拟合参数w\I\sigma，维度(n_node, 2h+1)

    # Initializing childrens
    xmean = np.zeros(N) ## 训练用的待拟合参数（abc...），维度5 * (2 * highest_order + 1) + 1
    xmean[0:N_para] = start_point_w  ## 初始化wE
    xmean[N_para:2 * (N_para)] = start_point_i    ## 初始化I
    xmean[2 * (N_para)] = init_para[2 * n_node]  ## 初始化G
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma  ## 初始化sigma噪声强度
    xmean[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I    ## 初始化wI
    xmean[4 * (N_para) + 1:N] = start_point_w_G  ## 初始化wG

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch   ## 每个参数集500次迭代
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda    ## 每代（每轮迭代）Lamda=500个参数集
    mu = training_config.mu ## 每代保留数量
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1)) ## 对mu个最优参数加权平均，维度mu=40
    weights = weights / np.sum(weights) ## 迭代中weights不变
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = start_point_w[0] / 2
    D[N_para:2 * (N_para)] = start_point_i[0] / 2
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    D[4 * (N_para) + 1:N] = start_point_w_G[0] / 2
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda]) ## 记录每次迭代的参数，只增加不修改
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:  ## 每个参数集500次迭代，即遗传500代
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # Generating lambda offspring
        arx[:, 0] = xmean
        j = 0   ## 个体序号0-499
        while j < Lambda:   ## 每代（每轮迭代）Lamda=500个参数集，即每代500个体（筛选40加权平均，作为下一代起点）
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = template_mat @ arx[0:2 * highest_order +
                                                         1, j]
            input_para[n_node:2 * n_node,
                       j] = template_mat @ arx[N_para:2 *
                                               (N_para), j]
            input_para[2 * n_node:2 * n_node +
                       1, j] = arx[2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = template_mat @ arx[2 * (
                N_para) + 1:3 * (
                N_para)+1, j]
            input_para[3 * n_node + 1:4 * n_node + 1, j] = template_mat @ arx[3 * (
                N_para) + 1:4 * (
                N_para) + 1, j]
            input_para[4 * n_node + 1:dim, j] = template_mat @ arx[4 * (
                    N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                j = j - 1
            j = j + 1
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)
        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_fusion(
            input_para, n_dup)
        countloop = countloop + 1

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost) ## 升序排序
        arindex = np.argsort(total_cost)    ## 升序排序后序列，在排序前的索引
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)  ## (N,mu)@(mu,1) = (N,1)。迭代中权重weights不变
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)
        # print('******** Generation: ' + str(countloop) + ' ********')
        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')


def CBIG_mfm_optimization_main_fusion_heter(gpu_index=0, random_seed=1):  ## 神经胶质，异质
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Fusion Heter', flush=True)
    # print('Environment Preparing...')

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # print('Initializing...')

    # Initializing input parameters
    # highest_order = 1
    n_node = system_config.n_roi ## number of rois, 68 for Desikan
    N = 5 * n_node + 1   ## 4(we,I,wi,wg)*68(DK) +2(G,sigma)
    # N = 5 * (2 * highest_order + 1) + 1
    # N_para = 2 * highest_order + 1
    N_para = n_node ## 异质化训练参数的异质数量
    dim = n_node * 5 + 1    ## 5(we,I,sigma,wi,wg)+1(G)

    search_range = np.zeros((dim, 2))
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI, wG
    
    init_para = rng.uniform(0, 1, dim) * (
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]
    
    start_point_w = init_para[0:n_node]
    start_point_i = init_para[n_node:n_node * 2]
    start_point_sigma = init_para[n_node * 2 + 1:n_node * 3 + 1]
    start_point_w_I = init_para[n_node * 3 + 1:n_node * 4 + 1]
    start_point_w_G = init_para[n_node * 4 + 1:dim]

    # Initializing childrens
    xmean = np.zeros(N)
    xmean[0:N_para] = start_point_w
    xmean[N_para:2 * (N_para)] = start_point_i
    xmean[2 * (N_para)] = init_para[2 * n_node]
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma
    xmean[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I
    xmean[4 * (N_para) + 1:N] = start_point_w_G

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda
    mu = training_config.mu
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1))
    weights = weights / np.sum(weights)
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = search_range[0,1] / 8
    D[N_para:2 * (N_para)] = search_range[n_node, 1] / 8
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:4 * (N_para) + 1] = search_range[3 * (n_node) + 1, 1] / 8
    D[4 * (N_para) + 1:N] = search_range[4 * (n_node) + 1, 1] / 8
    # D[0:N_para] = start_point_w[0] / 2
    # D[N_para:2 * (N_para)] = start_point_i[0] / 2
    # D[2 * (N_para)] = 0.4
    # D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    # D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    # D[4 * (N_para) + 1:N] = start_point_w_G[0] / 2
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # print('Evolution loop...')

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda])
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        # Generating lambda offspring
        arx[:, 0] = xmean   ## (N_para=n_node,1)
        j = 0 ## 个体序号0-499
        max_retries = 10000  # 添加最大重试次数限制
        retry_count = 0
        while j < Lambda:
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = arx[
                                                    0:N_para, j]
            input_para[n_node:2 * n_node, j] = arx[
                                                    N_para:2 * (N_para), j]
            input_para[2 * n_node:2 * n_node + 1, j] = arx[
                                                    2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = arx[
                                                    2 * (N_para) + 1:3 * (N_para)+1, j]
            input_para[3 * n_node + 1:4 * n_node + 1, j] = arx[
                                                    3 * (N_para) + 1:4 * (N_para) + 1, j]
            input_para[4 * n_node + 1:dim, j] = arx[
                                                    4 * (N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                if retry_count < max_retries:
                    j = j - 1
                    retry_count += 1
                else:
                    # 超过重试次数，使用边界截断
                    input_para[:, j] = np.clip(input_para[:, j], search_range[:, 0], search_range[:, 1])
                    # 更新arx以保持一致性
                    arx[0:N_para, j] = input_para[0:n_node, j]
                    arx[N_para:2*(N_para), j] = input_para[n_node:2*n_node, j]
                    arx[2*(N_para), j] = input_para[2*n_node, j]
                    arx[2*(N_para)+1:3*(N_para)+1, j] = input_para[2*n_node+1:3*n_node+1, j]
                    arx[3*(N_para)+1:4*(N_para)+1, j] = input_para[3*n_node+1:4*n_node+1, j]
                    arx[4*(N_para)+1:N, j] = input_para[4*n_node+1:dim, j]
                    retry_count = 0
            else:
                retry_count = 0  # 重置计数器
            j = j + 1
        
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)

        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_fusion(
            input_para, n_dup)
        countloop = countloop + 1

        # print('Calculating costs of offspring over, time: ', time.time() - start_time, flush=True)

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost)
        arindex = np.argsort(total_cost)
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)

        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def CBIG_mfm_optimization_main_neuro_para(gpu_index=0, random_seed=1): ## 神经胶质，参数化
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Neuro Para', flush=True)
    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Initializing input parameters
    highest_order = 1
    N_para = 2 * highest_order + 1
    N = 4 * (N_para) + 1 ## 2*highest_order + 1，1是0阶，2是myelin和grad各1阶。“阶”来自多项式
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0] ## 维度(n_roi,1) 
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]
    dim = 4 * n_node + 1

    search_range = np.zeros((dim, 2))   ## 初始化范围，实数闭区间
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI

    init_para = rng.uniform(0, 1, dim) * (  ## 维度(dim,1)
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]   ## 初始化为范围内随机实数，闭区间
    start_point_w, template_mat = get_init(myelin_data, gradient_data,  ## 
                                           highest_order, 
                                           init_para[0:n_node])
    start_point_i, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order,
                                           init_para[n_node:n_node * 2])
    start_point_sigma, template_mat = get_init(myelin_data, gradient_data,
                                               highest_order,
                                               init_para[n_node * 2 + 1:n_node * 3 + 1])
    start_point_w_I, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order, 
                                           init_para[n_node * 3 + 1:dim])

    ## start_point 维度为(2 * highest_order + 1, 1)。训练用的待拟合参数
    ## template_mat = cmatrix 线性多项式的项，用于从训练参数abc生成拟合参数w\I\sigma，维度(n_node, 2h+1)

    # Initializing childrens
    xmean = np.zeros(N) ## 训练用的待拟合参数（abc...），维度5 * (2 * highest_order + 1) + 1
    xmean[0:N_para] = start_point_w  ## 初始化wE
    xmean[N_para:2 * (N_para)] = start_point_i    ## 初始化I
    xmean[2 * (N_para)] = init_para[2 * n_node]  ## 初始化G
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma  ## 初始化sigma噪声强度
    xmean[3 * (N_para) + 1:N] = start_point_w_I    ## 初始化wI

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch   ## 每个参数集500次迭代
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda    ## 每代（每轮迭代）Lamda=500个参数集
    mu = training_config.mu ## 每代保留数量
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1)) ## 对mu个最优参数加权平均，维度mu=40
    weights = weights / np.sum(weights) ## 迭代中weights不变
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = start_point_w[0] / 2
    D[N_para:2 * (N_para)] = start_point_i[0] / 2
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:N] = start_point_w_I[0] / 2
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda]) ## 记录每次迭代的参数，只增加不修改
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:  ## 每个参数集500次迭代，即遗传500代
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # Generating lambda offspring
        arx[:, 0] = xmean
        j = 0   ## 个体序号0-499
        out_of_range = 0
        while j < Lambda:   ## 每代（每轮迭代）Lamda=500个参数集，即每代500个体（筛选40加权平均，作为下一代起点）
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = template_mat @ arx[0:2 * highest_order +
                                                         1, j]
            input_para[n_node:2 * n_node,
                       j] = template_mat @ arx[N_para:2 *
                                               (N_para), j]
            input_para[2 * n_node:2 * n_node +
                       1, j] = arx[2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = template_mat @ arx[2 * (
                N_para) + 1:3 * (
                N_para)+1, j]
            input_para[3 * n_node + 1:dim, j] = template_mat @ arx[3 * (
                N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                out_of_range = out_of_range + 1
                if out_of_range % 100000 == 0:  ## 超出范围10次，重新生成
                    print('out of range: ', out_of_range, 'valid: ',j, flush=True)
                j = j - 1
            j = j + 1
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)
        # print('train start')  ###
        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_neuro(
            input_para, n_dup)
        # print('train over')  ###
        countloop = countloop + 1

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost) ## 升序排序
        arindex = np.argsort(total_cost)    ## 升序排序后序列，在排序前的索引
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)  ## (N,mu)@(mu,1) = (N,1)。迭代中权重weights不变
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)
        # print('******** Generation: ' + str(countloop) + ' ********')
        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def CBIG_mfm_optimization_main_neuro_heter(gpu_index=0, random_seed=1):  ## 原版内容参数化，函数名不带parametric 
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Neuro Heter', flush=True)
    # print('Environment Preparing...')

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # print('Initializing...')

    # Initializing input parameters
    # highest_order = 1
    n_node = system_config.n_roi ## number of rois, 68 for Desikan
    N = 4 * n_node + 1   ## 4(we,I,wi,wg)*68(DK) +2(G,sigma)
    # N = 5 * (2 * highest_order + 1) + 1
    # N_para = 2 * highest_order + 1
    N_para = n_node ## 异质化训练参数的异质数量
    dim = n_node * 4 + 1    ## 5(we,I,sigma,wi,wg)+1(G)

    search_range = np.zeros((dim, 2))
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI
    
    init_para = rng.uniform(0, 1, dim) * (
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]
    
    start_point_w = init_para[0:n_node]
    start_point_i = init_para[n_node:n_node * 2]
    start_point_sigma = init_para[n_node * 2 + 1:n_node * 3 + 1]
    start_point_w_I = init_para[n_node * 3 + 1:dim]

    # Initializing childrens
    xmean = np.zeros(N)
    xmean[0:N_para] = start_point_w
    xmean[N_para:2 * (N_para)] = start_point_i
    xmean[2 * (N_para)] = init_para[2 * n_node]
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma
    xmean[3 * (N_para) + 1:N] = start_point_w_I

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda
    mu = training_config.mu
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1))
    weights = weights / np.sum(weights)
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = search_range[0,1] / 8
    D[N_para:2 * (N_para)] = search_range[n_node, 1] / 8
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:N] = search_range[3 * (n_node) + 1, 1] / 8
    # D[0:N_para] = start_point_w[0] / 2
    # D[N_para:2 * (N_para)] = start_point_i[0] / 2
    # D[2 * (N_para)] = 0.4
    # D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    # D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    # D[4 * (N_para) + 1:N] = start_point_w_G[0] / 2
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # print('Evolution loop...')

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda])
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        # Generating lambda offspring
        arx[:, 0] = xmean   ## (N_para=n_node,1)
        j = 0 ## 个体序号0-499
        max_retries = 10000  # 添加最大重试次数限制
        retry_count = 0
        while j < Lambda:
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = arx[
                                                    0:N_para, j]
            input_para[n_node:2 * n_node, j] = arx[
                                                    N_para:2 * (N_para), j]
            input_para[2 * n_node:2 * n_node + 1, j] = arx[
                                                    2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = arx[
                                                    2 * (N_para) + 1:3 * (N_para)+1, j]
            input_para[3 * n_node + 1:dim, j] = arx[
                                                    3 * (N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                if retry_count < max_retries:
                    j = j - 1
                    retry_count += 1
                else:
                    # 超过重试次数，使用边界截断
                    input_para[:, j] = np.clip(input_para[:, j], search_range[:, 0], search_range[:, 1])
                    # 更新arx以保持一致性
                    arx[0:N_para, j] = input_para[0:n_node, j]
                    arx[N_para:2*(N_para), j] = input_para[n_node:2*n_node, j]
                    arx[2*(N_para), j] = input_para[2*n_node, j]
                    arx[2*(N_para)+1:3*(N_para)+1, j] = input_para[2*n_node+1:3*n_node+1, j]
                    arx[3*(N_para)+1:N, j] = input_para[3*n_node+1:dim, j]
                    retry_count = 0
            else:
                retry_count = 0  # 重置计数器
            j = j + 1
        
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)

        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_neuro(
            input_para, n_dup)
        countloop = countloop + 1

        # print('Calculating costs of offspring over, time: ', time.time() - start_time, flush=True)

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost)
        arindex = np.argsort(total_cost)
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)

        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def CBIG_mfm_optimization_main_fusion_para_wg_heter(gpu_index=0, random_seed=1): ## 神经胶质，参数化
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Fusion Para wg_heter', flush=True)
    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Initializing input parameters
    highest_order = 1
    N_para = 2 * highest_order + 1
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0] ## 维度(68,1) 
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]
    N = 4 * (N_para) + 1 + n_node ## 估计参数量
    dim = 5 * n_node + 1 # 模型参数量

    search_range = np.zeros((dim, 2))   ## 初始化范围，实数闭区间
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI,wG

    init_para = rng.uniform(0, 1, dim) * (  ## 维度(dim,1)
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]   ## 初始化为范围内随机实数，闭区间
    
    start_point_w, template_mat = get_init(myelin_data, gradient_data,  ## 
                                           highest_order, 
                                           init_para[0:n_node])
    start_point_i, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order,
                                           init_para[n_node:n_node * 2])
    start_point_sigma, template_mat = get_init(myelin_data, gradient_data,
                                               highest_order,
                                               init_para[n_node * 2 + 1:n_node * 3 + 1])
    start_point_w_I, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order, 
                                           init_para[n_node * 3 + 1:n_node * 4 + 1])
    start_point_w_G = init_para[n_node * 4 + 1:dim]
    ## start_point 维度为(2 * highest_order + 1, 1)。训练用的待拟合参数
    ## template_mat = cmatrix 线性多项式的项，用于从训练参数abc生成拟合参数w\I\sigma，维度(n_node, 2h+1)

    # Initializing childrens
    xmean = np.zeros(N) ## 训练用的待拟合参数（abc...），维度5 * (2 * highest_order + 1) + 1
    xmean[0:N_para] = start_point_w  ## 初始化wE
    xmean[N_para:2 * (N_para)] = start_point_i    ## 初始化I
    xmean[2 * (N_para)] = init_para[2 * n_node]  ## 初始化G
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma  ## 初始化sigma噪声强度
    xmean[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I    ## 初始化wI
    xmean[4 * (N_para) + 1:N] = start_point_w_G  ## 初始化wG

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch   ## 每个参数集500次迭代
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda    ## 每代（每轮迭代）Lamda=500个参数集
    mu = training_config.mu ## 每代保留数量
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1)) ## 对mu个最优参数加权平均，维度mu=40
    weights = weights / np.sum(weights) ## 迭代中weights不变
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = start_point_w[0] / 2
    D[N_para:2 * (N_para)] = start_point_i[0] / 2
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    # D[4 * (N_para) + 1:N] = start_point_w_G[0] / 2
    D[4 * (N_para) + 1:N] = search_range[4 * (n_node) + 1, 1] / 8
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda]) ## 记录每次迭代的参数，只增加不修改
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:  ## 每个参数集500次迭代，即遗传500代
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # Generating lambda offspring
        arx[:, 0] = xmean
        j = 0   ## 个体序号0-499
        while j < Lambda:   ## 每代（每轮迭代）Lamda=500个参数集，即每代500个体（筛选40加权平均，作为下一代起点）
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = template_mat @ arx[
                                                            0:N_para, j]
            input_para[n_node:2 * n_node, j] = template_mat @ arx[
                                                            N_para:2 * (N_para), j]
            input_para[2 * n_node:2 * n_node + 1, j] = arx[
                                                            2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = template_mat @ arx[
                                                            2 * (N_para) + 1:3 * (N_para) + 1, j]
            input_para[3 * n_node + 1:4 * n_node + 1, j] = template_mat @ arx[
                                                            3 * (N_para) + 1:4 * (N_para) + 1, j]
            input_para[4 * n_node + 1:dim, j] = arx[
                                                            4 * (N_para) + 1:N, j]

            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                j = j - 1
            j = j + 1

        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)

        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_fusion(
            input_para, n_dup)
        countloop = countloop + 1

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost) ## 升序排序
        arindex = np.argsort(total_cost)    ## 升序排序后序列，在排序前的索引
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)  ## (N,mu)@(mu,1) = (N,1)。迭代中权重weights不变
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)
        # print('******** Generation: ' + str(countloop) + ' ********')
        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def CBIG_mfm_optimization_main_fusion_heter_gammag(gpu_index=0, random_seed=1):  ## 神经胶质，异质
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Fusion Heter Gamma_G', flush=True)
    # print('Environment Preparing...')

    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir

    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # print('Initializing...')

    # Initializing input parameters
    # highest_order = 1
    n_node = system_config.n_roi ## number of rois, 68 for Desikan
    N = 6 * n_node + 1   ## 4(we,I,wi,wg)*68(DK) +2(G,sigma)
    # N = 5 * (2 * highest_order + 1) + 1
    # N_para = 2 * highest_order + 1
    N_para = n_node ## 异质化训练参数的异质数量
    dim = n_node * 6 + 1    ## 6(we,I,sigma,wi,wg,gammag)+1(G)

    search_range = np.zeros((dim, 2))
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI, wG, gammaG
    
    init_para = rng.uniform(0, 1, dim) * (
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]
    
    start_point_w = init_para[0:n_node]
    start_point_i = init_para[n_node:n_node * 2]
    start_point_sigma = init_para[n_node * 2 + 1:n_node * 3 + 1]
    start_point_w_I = init_para[n_node * 3 + 1:n_node * 4 + 1]
    start_point_w_G = init_para[n_node * 4 + 1:n_node * 5 + 1]
    start_point_gamma_G = init_para[n_node * 5 + 1:dim]

    # Initializing childrens
    xmean = np.zeros(N)
    xmean[0:N_para] = start_point_w
    xmean[N_para:2 * (N_para)] = start_point_i
    xmean[2 * (N_para)] = init_para[2 * n_node]
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma
    xmean[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I
    xmean[4 * (N_para) + 1:5 * (N_para) + 1] = start_point_w_G
    xmean[5 * (N_para) + 1:N] = start_point_gamma_G

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda
    mu = training_config.mu
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1))
    weights = weights / np.sum(weights)
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = search_range[0,1] / 8
    D[N_para:2 * (N_para)] = search_range[n_node, 1] / 8
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:4 * (N_para) + 1] = search_range[3 * (n_node) + 1, 1] / 8
    D[4 * (N_para) + 1:5 * (N_para) + 1] = search_range[4 * (n_node) + 1, 1] / 8
    D[5 * (N_para) + 1:N] = search_range[5 * (n_node) + 1, 1] / 8
    # D[0:N_para] = start_point_w[0] / 2
    # D[N_para:2 * (N_para)] = start_point_i[0] / 2
    # D[2 * (N_para)] = 0.4
    # D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    # D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    # D[4 * (N_para) + 1:N] = start_point_w_G[0] / 2
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # print('Evolution loop...')

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda])
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        # Generating lambda offspring
        arx[:, 0] = xmean   ## (N_para=n_node,1)
        j = 0 ## 个体序号0-499
        max_retries = 10000  # 添加最大重试次数限制
        retry_count = 0
        while j < Lambda:
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = arx[
                                                    0:N_para, j]
            input_para[n_node:2 * n_node, j] = arx[
                                                    N_para:2 * (N_para), j]
            input_para[2 * n_node:2 * n_node + 1, j] = arx[
                                                    2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = arx[
                                                    2 * (N_para) + 1:3 * (N_para)+1, j]
            input_para[3 * n_node + 1:4 * n_node + 1, j] = arx[
                                                    3 * (N_para) + 1:4 * (N_para) + 1, j]
            input_para[4 * n_node + 1:5 * n_node + 1, j] = arx[
                                                    4 * (N_para) + 1:5 * (N_para) + 1, j]
            input_para[5 * n_node + 1:dim, j] = arx[
                                                    5 * (N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                if retry_count < max_retries:
                    j = j - 1
                    retry_count += 1
                else:
                    # 超过重试次数，使用边界截断
                    input_para[:, j] = np.clip(input_para[:, j], search_range[:, 0], search_range[:, 1])
                    # 更新arx以保持一致性
                    arx[0:N_para, j] = input_para[0:n_node, j]
                    arx[N_para:2*(N_para), j] = input_para[n_node:2*n_node, j]
                    arx[2*(N_para), j] = input_para[2*n_node, j]
                    arx[2*(N_para)+1:3*(N_para)+1, j] = input_para[2*n_node+1:3*n_node+1, j]
                    arx[3*(N_para)+1:4*(N_para)+1, j] = input_para[3*n_node+1:4*n_node+1, j]
                    arx[4*(N_para)+1:5*(N_para)+1, j] = input_para[4*n_node+1:5*n_node+1, j]
                    arx[5*(N_para)+1:N, j] = input_para[5*n_node+1:dim, j]
                    retry_count = 0
            else:
                retry_count = 0  # 重置计数器
            j = j + 1
        
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)

        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_fusion(
            input_para, n_dup)
        countloop = countloop + 1

        # print('Calculating costs of offspring over, time: ', time.time() - start_time, flush=True)

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost)
        arindex = np.argsort(total_cost)
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)

        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def CBIG_mfm_optimization_main_fusion_para_gammag(gpu_index=0, random_seed=1): ## 神经胶质，参数化
    '''
    This function is to implement the optimization processes of mean
    field model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.
    The optimization process is highly automatic and generate 500
    candidate parameter sets for
    main results.

    Args:
        gpu_index:      index of gpu used for optimization
        random_seed:    random seed for optimization
    Returns:
        None
    '''
    print('Fusion Para GammaG', flush=True)
    # Setting random seed and GPU
    torch.cuda.set_device(gpu_index)
    random_seed_cuda = random_seed
    random_seed_np = random_seed
    torch.manual_seed(random_seed_cuda)
    rng = np.random.Generator(np.random.PCG64(random_seed_np))

    # Create output folders
    output_path = system_config.output_path + training_config.output_dir
    
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Initializing input parameters
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0] ## 维度(68,1) 
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]
    dim = 6 * n_node + 1

    highest_order = 1
    N_para = 2 * highest_order + 1
    N = 5 * (N_para) + 1 + n_node ## 2*highest_order + 1，1是0阶，2是myelin和grad各1阶。“阶”来自多项式

    search_range = np.zeros((dim, 2))   ## 初始化范围，实数闭区间
    search_range[0:n_node, :] = [0, 1]  ## wE
    search_range[n_node:n_node * 2, :] = [0, 0.5]   ## I
    search_range[n_node * 2, :] = [1, 10]   ## G
    search_range[n_node * 2 + 1:n_node * 3 + 1, :] = [0.0005, 0.01] ## sigma
    search_range[n_node * 3 + 1:dim, :] = [0, 1]    ## wI,wG,gammaG
    init_para = rng.uniform(0, 1, dim) * (  ## 维度(dim,1)
        search_range[:, 1] - search_range[:, 0]) + search_range[:, 0]   ## 初始化为范围内随机实数，闭区间
    start_point_w, template_mat = get_init(myelin_data, gradient_data,  ## 
                                           highest_order, 
                                           init_para[0:n_node])
    start_point_i, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order,
                                           init_para[n_node:n_node * 2])
    start_point_sigma, template_mat = get_init(myelin_data, gradient_data,
                                               highest_order,
                                               init_para[n_node * 2 + 1:n_node * 3 + 1])
    start_point_w_I, template_mat = get_init(myelin_data, gradient_data,
                                           highest_order, 
                                           init_para[n_node * 3 + 1:n_node * 4 + 1])
    start_point_w_G, template_mat = get_init(myelin_data, gradient_data,
                                             highest_order, 
                                             init_para[n_node * 4 + 1:n_node * 5 + 1])
    start_point_gamma_G = init_para[n_node * 5 + 1:dim]
    ## start_point 维度为(2 * highest_order + 1, 1)。训练用的待拟合参数
    ## template_mat = cmatrix 线性多项式的项，用于从训练参数abc生成拟合参数w\I\sigma，维度(n_node, 2h+1)

    # Initializing childrens
    xmean = np.zeros(N) ## 训练用的待拟合参数（abc...），维度5 * (2 * highest_order + 1) + 1
    xmean[0:N_para] = start_point_w  ## 初始化wE
    xmean[N_para:2 * (N_para)] = start_point_i    ## 初始化I
    xmean[2 * (N_para)] = init_para[2 * n_node]  ## 初始化G
    xmean[2 * (N_para) + 1:3 * (N_para) + 1] = start_point_sigma  ## 初始化sigma噪声强度
    xmean[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I    ## 初始化wI
    xmean[4 * (N_para) + 1:5 * (N_para) + 1] = start_point_w_G  ## 初始化wG
    xmean[5 * (N_para) + 1:N] = start_point_gamma_G  ## 初始化wG

    # Initializing optimization hyper-parameters
    sigma = 0.15
    sigmaS = 0.15
    stoppoint = 0.3
    maxloop = training_config.max_epoch   ## 每个参数集500次迭代
    n_dup = 3

    # CMA-ES parameters setting
    Lambda = training_config.Lambda    ## 每代（每轮迭代）Lamda=500个参数集
    mu = training_config.mu ## 每代保留数量
    weights = np.log(mu + 1 / 2) - np.log(np.arange(1, mu + 1)) ## 对mu个最优参数加权平均，维度mu=40
    weights = weights / np.sum(weights) ## 迭代中weights不变
    mueff = 1 / np.sum(weights**2)

    # Strategy parameter setting: adaptation
    cc = (4 + mueff / N) / (N + 4 + 2 * mueff / N)
    cs = (mueff + 2) / (N + mueff + 5)
    c1 = 2 / ((N + 1.3)**2 + mueff)
    cmu = np.minimum(1 - c1,
                     2 * (mueff - 2 + 1 / mueff) / ((N + 2)**2 + mueff))
    damps = 1 + 2 * np.maximum(0, np.sqrt((mueff - 1) / (N + 1)) - 1) + cs

    # Initializing dynamic strategy parameters and constants'''
    pc = np.zeros(N)
    ps = np.zeros(N)
    B = np.eye(N)
    D = np.zeros(N)
    D[0:N_para] = start_point_w[0] / 2
    D[N_para:2 * (N_para)] = start_point_i[0] / 2
    D[2 * (N_para)] = 0.4
    D[2 * (N_para) + 1:3 * (N_para)+1] = 0.001 / 2
    D[3 * (N_para) + 1:4 * (N_para) + 1] = start_point_w_I[0] / 2
    D[4 * (N_para) + 1:5 * (N_para) + 1] = start_point_w_G[0] / 2
    D[5 * (N_para) + 1:N] = search_range[5 * (n_node) + 1, 1] / 8
    C = np.dot(np.dot(B, np.diag(np.power(D, 2))), B.T)
    Inmedia = np.diag(np.power(D, -1))
    invsqrtC = np.dot(np.dot(B, Inmedia), B.T)
    chiN = N**0.5 * (1 - 1 / (4 * N) + 1 / (21 * N ** 2))

    # Evolution loop
    countloop = 0
    arx = np.zeros([N, Lambda]) ## 记录每次迭代的参数，只增加不修改
    input_para = np.zeros((dim, Lambda))
    xmin = np.zeros([N + 3, maxloop])
    stop_count = 0
    while countloop < maxloop:  ## 每个参数集500次迭代，即遗传500代
        print('******** '+ system_config.title +' Generation: ' + str(countloop+1) + ' ********', flush=True)
        start_time = time.time()

        # Generating lambda offspring
        arx[:, 0] = xmean
        j = 0   ## 个体序号0-499
        while j < Lambda:   ## 每代（每轮迭代）Lamda=500个参数集，即每代500个体（筛选40加权平均，作为下一代起点）
            arx[:, j] = xmean + sigma * np.dot(B, (D * rng.standard_normal(N)))
            input_para[0:n_node, j] = template_mat @ arx[0:2 * highest_order +
                                                         1, j]
            input_para[n_node:2 * n_node,
                       j] = template_mat @ arx[N_para:2 *
                                               (N_para), j]
            input_para[2 * n_node:2 * n_node +
                       1, j] = arx[2 * (N_para), j]
            input_para[2 * n_node + 1:3*n_node+1, j] = template_mat @ arx[2 * (
                N_para) + 1:3 * (
                N_para)+1, j]
            input_para[3 * n_node + 1:4 * n_node + 1, j] = template_mat @ arx[3 * (
                N_para) + 1:4 * (
                N_para) + 1, j]
            input_para[4 * n_node + 1:5 * n_node + 1, j] = template_mat @ arx[4 * (
                N_para) + 1:5 * (
                N_para) + 1, j]
            input_para[5 * n_node + 1:dim, j] = arx[5 * (
                N_para) + 1:N, j]
            if (input_para[:, j] < search_range[:, 0]).any() or (
                    input_para[:, j] > search_range[:, 1]).any():
                j = j - 1
            j = j + 1
        print('Generating lambda offspring over, time: ', time.time() - start_time, flush=True)
        # Calculating costs of offspring
        total_cost, fc_cost, fcd_cost = fc.CBIG_combined_cost_train_fusion_gammag(
            input_para, n_dup)
        countloop = countloop + 1

        # Sort by total cost and compute weighted mean
        arfitsort = np.sort(total_cost) ## 升序排序
        arindex = np.argsort(total_cost)    ## 升序排序后序列，在排序前的索引
        xold = xmean
        xmean = np.dot(arx[:, arindex[0:mu]], weights)  ## (N,mu)@(mu,1) = (N,1)。迭代中权重weights不变
        xshow = xmean - xold

        # Cumulation
        ps = (1 - cs) * ps + np.sqrt(cs * (2 - cs) * mueff) * np.dot(
            invsqrtC, xshow) / sigma
        hsig = (np.linalg.norm(ps) / np.sqrt(1 - (1 - cs) **
                                             (2 * countloop)) / chiN <
                (1.4 + 2 / (N + 1))) * 1
        pc = (1 - cc) * pc + hsig * np.sqrt(cc *
                                            (2 - cc) * mueff) * xshow / sigma

        # Adapting covariance matrix C
        artmp = (1 / sigma) * (
            arx[:, arindex[0:mu]] - np.tile(xold, [mu, 1]).T)
        C = (1 - c1 - cmu) * C + c1 * (
            np.outer(pc, pc) + (1 - hsig) * cc * (2 - cc) * C) + cmu * np.dot(
                artmp, np.dot(np.diag(weights), artmp.T))

        # Adapting step size
        sigma = sigma * np.exp((cs / damps) * (np.linalg.norm(ps) / chiN - 1))
        sigma = min(sigma, sigmaS)

        # Decomposition
        if 1 > 1 / (c1 + cmu) / N / 10:
            C = np.triu(C, k=1) + np.triu(C).T
            D, B = np.linalg.eigh(C)
            D = D.real
            B = B.real
            D = np.sqrt(D)
            invsqrtC = np.dot(B, np.dot(np.diag(D**(-1)), B.T))

        # Monitoring the evolution status
        ps_norm = np.linalg.norm(ps)
        # print('******** Generation: ' + str(countloop) + ' ********')
        # print('Norm of P-sigma: ', ps_norm)
        print('The mean of total cost: ', np.mean(arfitsort[0:mu]), flush=True)
        # print('Sigma: ', sigma)

        xmin[0:N, countloop - 1] = arx[:, arindex[0]]
        xmin[N, countloop - 1] = fc_cost[arindex[0]]
        xmin[N + 1, countloop - 1] = fcd_cost[arindex[0]]
        xmin[N + 2, countloop - 1] = np.min(total_cost)
        print('Best total cost: ', np.min(total_cost), flush=True)
        # print('FC correlation cost: ', fc_cost[arindex[0]])
        # print('FCD KS statistics cost: ', fcd_cost[arindex[0]])

        elapsed_time = time.time() - start_time
        print('Elapsed time for this evolution is : ', elapsed_time, flush=True)
        # print('******************************************', flush=True)

        # break
        if arfitsort[0] < stoppoint and ps_norm < 11:
            stop_count = stop_count + 1
        if stop_count >= 5 or sigma < 0.001:
            break

    save_name = [output_path
                 ] + ['random_initialization_',
                      str(random_seed), '.csv']
    np.savetxt(''.join(save_name), xmin, delimiter=',')

def train_main(plan_type):
    cases = {
    plan.neuro_heter: CBIG_mfm_optimization_main_neuro_heter,
    plan.neuro_para: CBIG_mfm_optimization_main_neuro_para,
    plan.fusion_heter: CBIG_mfm_optimization_main_fusion_heter,
    plan.fusion_para: CBIG_mfm_optimization_main_fusion_para,
    plan.fusion_para_wg_heter: CBIG_mfm_optimization_main_fusion_para_wg_heter,
    plan.fusion_heter_gammag: CBIG_mfm_optimization_main_fusion_heter_gammag,
    plan.fusion_para_gammag: CBIG_mfm_optimization_main_fusion_para_gammag,
    }
    return cases.get(plan_type, plan.fusion_heter)

# def CBIG_mfm_optimization_main(gpu_index=0, random_seed=1):
#     CBIG_mfm_optimization_main_neuro_para(gpu_index, random_seed)

if __name__ == "__main__":
    from pMFM_config import print_config
    print_config()
    print(system_config.title, flush=True)
    print('Start...',time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
    warnings.filterwarnings("ignore", category=RuntimeWarning)

    plan_type = system_config.plan_type   ##
    for i in system_config.train_random_seeds:  ## 左闭右开
        print("**** Random seed: ", i, flush=True)
        train_main(plan_type)(random_seed=i)
        print("**** Random seed: ", i, " finished.")
        print('End...',time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
