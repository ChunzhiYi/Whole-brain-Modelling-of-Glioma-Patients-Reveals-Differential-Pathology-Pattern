"""
part1_pMFM_main.train_vali 的 Docstring
    mouse
    集成训练和验证的主脚本
    在单卡环境下执行串行逻辑任务
    载入pMFM_config作为统一配置
    可通过命令行参数配置GPU索引、计划类型、组别、折数和随机种子
    可独立运行python train_vali.py --gpu <GPU_INDEX> --plan <PLAN_TYPE> --group <GROUP> --fold <FOLD> --seeds <SEEDS>
    运行前注意修改pMFM_config.py中的默认配置
"""
import os
import shutil
import sys

# 配置检测和复制函数（Mouse版本）
def setup_mouse_config():
    """设置Mouse配置文件：检测pMFM_config_mouse.py并复制为pMFM_config.py"""
    config_source = "pMFM_config_mouse.py"
    config_target = "pMFM_config.py"
    
    # 检查源配置文件是否存在
    if not os.path.exists(config_source):
        if not os.path.exists(config_target):
            print(f"错误: 找不到Mouse配置文件 {config_source} 和 {config_target}")
            sys.exit(1)
        else:
            print(f"警告: 找不到Mouse配置文件 {config_source}，使用现有 {config_target}")
    else:
        # 如果目标文件已存在，检查是否需要覆盖
        if os.path.exists(config_target):
            # 比较文件内容，如果不同则覆盖
            with open(config_source, 'r', encoding='utf-8') as src, open(config_target, 'r', encoding='utf-8') as tgt:
                if src.read() != tgt.read():
                    print(f"检测到Mouse配置文件变更，更新 {config_target}")
                    shutil.copy2(config_source, config_target)
                else:
                    print(f"Mouse配置文件 {config_target} 已是最新")
        else:
            # 目标文件不存在，直接复制
            print(f"复制Mouse配置文件: {config_source} -> {config_target}")
            shutil.copy2(config_source, config_target)

# 执行配置文件设置
try:
    setup_mouse_config()
except Exception as e:
    print(f"Mouse配置文件设置失败: {e}")
    sys.exit(1)

from pMFM_basic_functions_main import nanlog_config
from pMFM_step1_training_main import *
from pMFM_step2_validation_main import *
from pMFM_config import print_config, system_config
import time
import warnings
import argparse

def main():
    warnings.filterwarnings("ignore", category=RuntimeWarning)

    # 从命令行参数获取配置（新增）
    parser = argparse.ArgumentParser()
    if parser is None:
        print("parser is None, using default config.")
    else:
        parser.add_argument('--gpu', type=int, default=system_config.gpu_index, help='GPU index to use, default: 0')
        parser.add_argument('--plan', type=int, default=system_config.plan_type, help='Plan type, 1=neuro_heter, 2=neuro_para, 3=fusion_heter, 4=fusion_para...see pMFM_config.plan, default: 4')
        parser.add_argument('--group', type=str, default=system_config.group_name, help='Group name, ctl or exp, default: ctl')
        parser.add_argument('--fold', type=int, default=system_config.fold_num, help='Fold number, 1 to 5, default: 1')
        parser.add_argument('--seeds', type=str, default=','.join(map(str, system_config.train_random_seeds)), help='Random seeds, comma separated, default: 0,1,2,3,4')
        args = parser.parse_args()
        
        # 设置配置（修改：使用命令行参数）
        random_seeds_list = [int(seed) for seed in args.seeds.split(',')]
        system_config.set_config(
            gpu_index=args.gpu,
            plan_type=args.plan,
            group=args.group,
            fold=args.fold,
            random_seeds=random_seeds_list
        )
    
    print_config(save_to_file=False)
    print(system_config.title, flush=True)
    print('Start...', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

    plan_type = system_config.plan_type
    for i in system_config.train_random_seeds:
        try:
            gpu_index = system_config.gpu_index
            print(f"**** Random seed: {i} | Using GPU: {gpu_index}", flush=True)
            
            # from pMFM_config import training_config
            # print('using FC:',training_config.FC_training, flush=True)
            # 调用训练函数并传入GPU索引
            train_main(plan_type)(gpu_index=gpu_index, random_seed=i)
            
            print(f"**** Random seed: {i} finished.")
            print(system_config.title, flush=True)
            print('End...', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        except RuntimeError as e:
            print(f"Error: {str(e)}")
            break  # 异常终止循环
        
        try:
            nanlog_config.print_log(f'../logs/seed{i}_train_nanlog_{time.strftime("%Y%m%d_%H%M%S", time.localtime())}.txt')
        except:
            print("Error: Failed to print nanlog.")

        try:
            gpu_index = system_config.gpu_index
            print(f"**** Random seed: {i} | Using GPU: {gpu_index}", flush=True)
            
            # from pMFM_config import validation_config
            # print('using FC:',validation_config.FC_training, flush=True)
            # 验证和测试
            vali_main(plan_type)(gpu_index=gpu_index, set_range=[i])
            print(system_config.title, flush=True)
        except RuntimeError as e:
            print(f"Error: {str(e)}")
            break  # 异常终止循环

        try:
            nanlog_config.print_log(f'../logs/seed{i}_vali_nanlog_{time.strftime("%Y%m%d_%H%M%S", time.localtime())}.txt')
        except:
            print("Error: Failed to print nanlog.")

if __name__ == "__main__":
    main()