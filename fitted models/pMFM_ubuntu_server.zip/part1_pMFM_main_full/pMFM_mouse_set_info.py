class mouse_set_info:
    '''
        Set information for mouse 20 data
        10 control mice and 10 experimental mice
    '''
    def __init__(self, group='ctl', index=1):
        '''
        :param group: 'ctl' or 'exp'
        :param index: 1-5
        '''

        group_name = 'control' if group=='ctl' else 'experimental'
        input_path = '../input_mouse_20_set'
        
        self.title = 'mouse_'+group_name+'_fold'+str(index)

        # training_config
        # input
        self.FCD_name_training = 'fcd_histcum'
        self.FCD_training = input_path+'/mouse_FCD/'+group_name+'_fold'+str(index)+'_train_fcd.mat'
        self.SC_training = input_path+'/mouse_SC/'+group_name+'_fold'+str(index)+'_train_sc.csv'
        self.FC_training = input_path+'/mouse_FC/'+group_name+'_fold'+str(index)+'_train_fc.csv'
        self.myelin_training = input_path+'/mouse_myelin/'+group_name+'_fold'+str(index)+'_train_myelin.csv'
        self.RSFC_gradient_training = input_path+'/mouse_gradient/'+group_name+'_fold'+str(index)+'_train_gradient.csv'

        # validation_config
        # input
        self.FCD_name_validation = 'fcd_histcum'
        self.FCD_validation = input_path+'/mouse_FCD/'+group_name+'_fold'+str(index)+'_vali_fcd.mat'
        self.SC_validation = input_path+'/mouse_SC/'+group_name+'_fold'+str(index)+'_vali_sc.csv'
        self.FC_validation = input_path+'/mouse_FC/'+group_name+'_fold'+str(index)+'_vali_fc.csv'

