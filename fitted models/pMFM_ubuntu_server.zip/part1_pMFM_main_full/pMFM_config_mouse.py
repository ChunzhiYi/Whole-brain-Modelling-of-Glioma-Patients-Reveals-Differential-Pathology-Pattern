"""
    mouse config file
"""
from pMFM_mouse_set_info import mouse_set_info
from enum import Enum

# 在 pMFM_config.py 中添加描述符类
class DynamicConfigAttribute:
    """动态配置属性描述符"""
    def __init__(self, attr_name):
        self.attr_name = attr_name
    
    def __get__(self, obj, objtype=None):
        # 动态获取 system_config.set_info 的最新值
        return getattr(system_config.set_info, self.attr_name)

class plan(Enum):
    neuro_heter = 1
    neuro_para = 2
    fusion_heter = 3
    fusion_para = 4
    fusion_para_wg_heter = 5
    fusion_heter_gammag = 6
    fusion_para_gammag = 7
    def is_fusion_gamma():
        return system_config.plan_type.value in [6]
    def is_fusion():
        return system_config.plan_type.value in [3,4]
    def is_para():
        return system_config.plan_type.value in [2,4]

class system_config:
#     # warm up period (in frames)
#     warmup = 5000
#     # pre-simulation period (in minutes)
#     t_pre = 2.4
#     # Euler integration time step size for training (in seconds)
#     # For proper downsampling, note that TR divided by the time step size must be an integer
#     dt_training = 0.006
#     # Euler integration time step size for validation (in seconds)
#     dt_validation = 0.0005
#     # Euler integration time step size for testing (in seconds)
#     dt_test = 0.0005
#     # Euler integration time step size for extrapolation, where applicable (in seconds)
#     dt_extrapolation = 0.0005
#     # minimum/maximum excitatory firing rate (Hz)
#     rE_min = 2.7
#     rE_max = 3.3
#     # GPU index, put -1 if you don't want to specify a GPU index (for example, running on a cluster)
#     GPU_index = 0
#     # number of multiprocessing process
#     num_thread = 5

    gpu_index = 0
    # sliding window length, usually equals to 60s/TR
    window_size = 60    ## 83 for HCP
    # tmbta
    n_roi = 122

    group_name = 'ctl'
    fold_num = 1
    set_info = mouse_set_info(group_name,fold_num)
    title = set_info.title

    # random seeds
    train_random_seeds = [1]
    # train_random_seeds = [1,2,3,4,5,6,7,8,9,10]
    # vali_random_seeds = [1,2,3,4,5,6,7,8,9,10]  # no use
    # test_random_seeds = [1,2,3,4,5,6,7,8,9,10]  # no use for mouse

    plan_type = plan.fusion_para # 1=neuro_heter, 2=neuro_para, 3=fusion_heter, 4=fusion_para, 5=fusion_para_wg_heter
    output_root = '../output/mouse/'
    output_path = output_root + plan_type.name + '/'+title+'/'

    # cost weights
    FC_cost_weight = 1
    FCD_cost_weight = 1

    # using hierarchy 分层优化方案
    hierarchy_cost_mode = False
    select_by_hierarchy_cost = False
    FC_cost_threshold = 0.64

    def set_config(gpu_index: int, plan_type: int, group: str, fold: int, random_seeds: list):
        ## 不会更新training_config等里的路径, 因此需要DynamicConfigAttribute描述符类
        ## 后续做其他修改时注意
        system_config.gpu_index = gpu_index
        system_config.plan_type = plan(plan_type)
        system_config.train_random_seeds = random_seeds
        system_config.group_name = group
        system_config.fold_num = fold
        system_config.set_info = mouse_set_info(group, fold)
        system_config.title = system_config.set_info.title
        system_config.output_path = system_config.output_root + system_config.plan_type.name+'/'+system_config.title+'/'

class BOLD_config:
    # TR of BOLD signals (s)
    TR = 1
    # number of BOLD frames
    n_frame = 590
    timelong = (int)(n_frame * TR)

# class hemodynamic:
#     # Balloon-Windkessel hemodynamic model parameters
#     p_constant = 0.34
#     v_0 = 0.02
#     beta = 0.65
#     gamma = 0.41
#     tau = 0.98
#     alpha = 0.33

# class neuralMassModel:
#     # effective external current
#     I0 = 0.382
#     # kinetic parameter
#     gamma = 0.641

# class excitatory:
#     # steady-state excitatory current (nA)
#     I_E_ss = 0.3772259651
#     # steady-state excitatory synaptic gating variable
#     S_E_ss = 0.1641205151
#     # excitatory scaling factor for effective external input
#     W_E = 1.
#     # excitatory synaptic coupling (nA)
#     J_NMDA = 0.15
#     # excitatory firing rate parameters
#     a_E = 310.
#     b_E = 125.
#     d_E = 0.16
#     # excitatory time constant (s)
#     tau_E = 0.1

# class inhibitory:
#     # steady-state inhibitory current (nA)
#     I_I_ss = 0.296385800197336
#     # steady-state excitatory synaptic gating variable
#     S_I_ss = 0.2433408985
#     # inhibitory firing rate parameters
#     a_I = 615.
#     b_I = 177.
#     d_I = 0.087
#     # inhibitory time constant (s)
#     tau_I = 0.01
#     # inhibitory scaling factor for effective external input
#     W_I = 0.7
    
class glia_config:
#     # steady-state inhibitory current (nA)
#     I_I_ss = 0.296385800197336
#     # steady-state excitatory synaptic gating variable
#     S_I_ss = 0.2433408985
#     # inhibitory firing rate parameters
#     a_I = 615.
#     b_I = 177.
#     d_I = 0.087
#     # inhibitory time constant (s)
#     tau_I = 0.01
#     # inhibitory scaling factor for effective external input
#     W_I = 0.7
    # glia firing rate parameters
    a_G = 9.5791
    b_G = 0.0105
    d_G = 95.1605
    # Parameters for glia activity
    tau_G = 0.01
    # Parameters for glial-neuron coupling
    gamma_g = 0.5
    xi = 0.8

class training_config:
    output_dir = 'step1_training_results/'
    # output_file = training
    # input
    FCD_training = DynamicConfigAttribute('FCD_training')
    FCD_name = DynamicConfigAttribute('FCD_name_training')
    SC_training = DynamicConfigAttribute('SC_training')
    FC_training = DynamicConfigAttribute('FC_training')
    myelin_training = DynamicConfigAttribute('myelin_training')
    RSFC_gradient_training = DynamicConfigAttribute('RSFC_gradient_training')
    # myelin_training = '../input/Desikan_input/myelin.csv'
    # RSFC_gradient_training = '../input/Desikan_input/rsfc_gradient.csv'
    # cost weights
    FC_cost_weight = system_config.FC_cost_weight
    FCD_cost_weight = system_config.FCD_cost_weight

    # iteration
    max_epoch = 500   ## 每个参数集500次迭代，也是输出文件保存参数集数
    # CMA-ES parameters setting
    Lambda = 500    ## 每代（每轮迭代）Lamda=500个参数集
    mu = 40 ## 每代保留数量
    # # weights for cost function terms
    # FC_corr_weight = 1
    # FC_L1_weight = 1
    # FCD_KS_weight = 1
    # # number of training epochs
    # num_epoch = 100
    # # spatial constraint
    # spatial_constraint = 0
    # # set wEI and wEE search range
    # wEI_a = 11
    # wEI_b = 0
    # wEI_c = 22
    # wEI_d = -6
    # wEE_a = 20
    # wEE_b = 0
    # wEE_c = 20
    # wEE_d = -3
    # # low-memory mode? (1 = yes, 0 = no)
    # low_mem = 0

class validation_config:
    output_dir = 'step2_validation_results/'
    # output_file = validation
    FCD_validation = DynamicConfigAttribute('FCD_validation')
    FCD_name = DynamicConfigAttribute('FCD_name_validation')
    SC_validation = DynamicConfigAttribute('SC_validation')
    FC_validation = DynamicConfigAttribute('FC_validation')
    # actually fixed, n_trial*50 = number of set per random_initialization (500 sets)
    # cost weights
    FC_cost_weight = system_config.FC_cost_weight
    FCD_cost_weight = system_config.FCD_cost_weight
    n_trial = 10 # in each trial, 50 parameter sets are validated in parallel
    # # low-memory mode? (1 = yes, 0 = no)
    # low_mem = 1

class test_config: # useless for mouse
    output_dir = '/step3_test_results/'
    FCD_test = '../input/Desikan_input/fcd_test.mat'
    FCD_name = 'fcd_histcum'
    SC_test = '../input/Desikan_input/sc_test.csv'
    FC_test = '../input/Desikan_input/fc_test.csv'
    # cost weights
    FC_cost_weight = system_config.FC_cost_weight
    FCD_cost_weight = system_config.FCD_cost_weight
    # number of repeated forward simulations
    n_set = 100
    # number of repetition for averaging
    n_dup = 10
    # number of best solution from validation
    n_solution = 10
    # # similarity constraint (this is to prevent multiple solutions from being too similar in terms of correlation)
    # # in this case, solutions with a correlation of 0.98 or above with any of the previous solutions are considered as being too similar
    # similarity_threshold = 0.98

def print_config(save_to_file=True, file_path=None):
    """
    打印配置信息，可选择同时保存到文件
    
    Args:
        save_to_file: 是否保存到文件
        file_path: 文件保存路径，如果为None则使用默认路径
    """
    import os
    import inspect
    from datetime import datetime
    
    def is_simple_value(value):
        """判断是否为简单可显示的值"""
        if value is None:
            return True
        if isinstance(value, (int, float, bool, str)):
            return True
        if isinstance(value, (list, tuple, dict)):
            # 检查容器内元素是否都是简单类型
            if isinstance(value, (list, tuple)):
                return all(is_simple_value(item) for item in value)
            elif isinstance(value, dict):
                return all(is_simple_value(k) and is_simple_value(v) for k, v in value.items())
        if isinstance(value, Enum):
            return True
        return False
    
    def format_value(value):
        """格式化值用于显示"""
        if value is None:
            return "None"
        elif isinstance(value, str):
            return f"'{value}'"
        elif isinstance(value, (list, tuple)):
            items = [format_value(item) for item in value]
            if isinstance(value, tuple):
                return f"({', '.join(items)})"
            else:
                return f"[{', '.join(items)}]"
        elif isinstance(value, dict):
            items = [f"{format_value(k)}: {format_value(v)}" for k, v in value.items()]
            return f"{{{', '.join(items)}}}"
        elif isinstance(value, Enum):
            return f"{value.__class__.__name__}.{value.name}"
        else:
            return str(value)
    
    def get_class_source(cls):
        """获取类的源代码"""
        try:
            source = inspect.getsource(cls)
            return source
        except (TypeError, OSError):
            return None
    
    def parse_class_attributes(source_code):
        """解析类的属性定义"""
        if not source_code:
            return []
        
        attributes = []
        lines = source_code.split('\n')
        in_class = False
        indent_level = 0
        
        for line in lines:
            stripped = line.strip()
            
            # 跳过空行和注释
            if not stripped or stripped.startswith('#'):
                continue
            
            # 检测类开始
            if stripped.startswith('class '):
                in_class = True
                # 计算缩进级别
                indent_level = len(line) - len(line.lstrip())
                continue
            
            if in_class:
                # 检查当前行的缩进级别
                current_indent = len(line) - len(line.lstrip())
                if current_indent <= indent_level and stripped:
                    # 缩进小于等于类级别，可能是类结束或新类开始
                    break
                
                # 解析属性定义（简单的等号赋值）
                if '=' in line and not stripped.startswith('def ') and not stripped.startswith('@'):
                    # 分割等号左右部分
                    parts = line.split('=', 1)
                    if len(parts) == 2:
                        attr_name = parts[0].strip()
                        # 跳过私有属性和特殊方法
                        if not attr_name.startswith('_') or attr_name.startswith('__') and attr_name.endswith('__'):
                            attr_value_expr = parts[1].strip()
                            # 移除行尾注释
                            if '#' in attr_value_expr:
                                attr_value_expr = attr_value_expr.split('#')[0].strip()
                            attributes.append((attr_name, attr_value_expr))
        
        return attributes
    
    output_lines = []
    
    # 收集所有输出内容
    output_lines.append(f'plan: {plan(system_config.plan_type).name}')
    output_lines.append(f'train vali: {system_config.title}')
    output_lines.append('')
    output_lines.append('***************** Config Values *****************')
    
    # 定义要打印的配置类
    config_classes = [
        ('system_config', system_config),
        ('BOLD_config', BOLD_config),
        ('glia_config', glia_config),
        ('training_config', training_config),
        ('validation_config', validation_config),
        ('test_config', test_config)
    ]
    
    for class_name, cls in config_classes:
        output_lines.append(f'\n--- {class_name} ---')
        
        # 获取类的源代码
        source_code = get_class_source(cls)
        attribute_defs = parse_class_attributes(source_code)
        
        # 获取类的所有属性
        for attr_name, attr_expr in attribute_defs:
            try:
                # 获取属性当前值
                attr_value = getattr(cls, attr_name)
                
                # 判断是否为简单值
                if is_simple_value(attr_value):
                    # 打印属性名和当前值
                    formatted_value = format_value(attr_value)
                    output_lines.append(f'{attr_name} = {formatted_value}')
                else:
                    # 复杂值，保留原始表达式
                    output_lines.append(f'{attr_name} = {attr_expr}')
                    
            except AttributeError:
                # 属性不存在，跳过
                continue
            except Exception as e:
                # 获取属性值时出错，使用原始表达式
                output_lines.append(f'{attr_name} = {attr_expr}  # Error: {str(e)}')
    
    output_lines.append('***********************************************')
    
    # 打印到控制台
    for line in output_lines:
        print(line)
    
    # 保存到文件
    if save_to_file:
        if file_path is None:
            # 使用默认路径
            file_path = f'../logs/config_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'
            # file_path = system_config.output_path + f'config_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'

        # 确保目录存在
        output_dir = os.path.dirname(file_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(f'====== Config Output - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} ======\n\n')
            for line in output_lines:
                f.write(line + '\n')
        
        print(f"\n配置已保存到: {file_path}")

if __name__ == "__main__":
    print_config()
