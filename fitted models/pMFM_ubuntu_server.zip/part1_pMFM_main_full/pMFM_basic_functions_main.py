# /usr/bin/env python
'''
Written by Kong Xiaolu and CBIG under MIT license:
https://github.com/ThomasYeoLab/CBIG/blob/master/LICENSE.md
'''

import csv
import math
import time
import numpy as np
import torch
import scipy.io as sio
from pMFM_config import *
'''********************  Functions for computing simulated BOLD signals
 *************************'''

def CBIG_mfm_multi_simulation_neuro(parameter, sc_mat, n_dup, t_epochlong, t_bold):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated multiple times to get
	stable result
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
		sc_mat:     N*N structural connectivity matrix
		n_dup:      Number of times each parameter set is simulated
		t_epochlong:total simulated time
		t_bold:      BOLD TR
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	d_t = 0.01
	# t_bold = BOLD_config.TR

	# Setting sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_num = parameter.shape[1]
	n_set = n_dup * n_num
	parameter = parameter.repeat(1, n_dup)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	w_l = k_p.shape[0]
	d_w = math.sqrt(d_t) * torch.randn(n_dup, n_nodes, w_l + 1000)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))
	# print('Warm up start') ###
	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I = CBIG_mfm_rfMRI_ode_inhibition_neuro(y_t, S_I, parameter, sc_mat)
		noise_level = d_w[:, :, i].repeat(1, 1, n_num).contiguous().view(
			-1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
	# print('Warm up end') ###
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I = CBIG_mfm_rfMRI_ode_inhibition_neuro(y_t, S_I, parameter, sc_mat, nanlog=True)
		noise_level = d_w[:, :, i + 1000].repeat(1, 1,
												 n_num).contiguous().view(
													 -1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)

		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d


def CBIG_mfm_multi_simulation_fusion(parameter, sc_mat, n_dup, t_epochlong, t_bold):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated multiple times to get
	stable result
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G for glial
		sc_mat:     N*N structural connectivity matrix
		n_dup:      Number of times each parameter set is simulated
		t_epochlong:total simulated time
		t_bold:      BOLD TR
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	d_t = 0.01
	# t_bold = BOLD_config.TR

	# Setting sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_num = parameter.shape[1]
	n_set = n_dup * n_num
	parameter = parameter.repeat(1, n_dup)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	S_g = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))
	dg = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001
	S_g[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	w_l = k_p.shape[0]
	d_w = math.sqrt(d_t) * torch.randn(n_dup, n_nodes, w_l + 1000)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion(y_t, S_I, S_g, parameter, sc_mat)
		noise_level = d_w[:, :, i].repeat(1, 1, n_num).contiguous().view(
			-1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion(y_t, S_I, S_g, parameter, sc_mat, nanlog=True)
		noise_level = d_w[:, :, i + 1000].repeat(1, 1,
												 n_num).contiguous().view(
													 -1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_multi_simulation_fusion_gammag(parameter, sc_mat, n_dup, t_epochlong, t_bold):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated multiple times to get
	stable result
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G for glial
					parameter[5*N+1:6*N+1]: gamma_g for glial-neuro coupling
		sc_mat:     N*N structural connectivity matrix
		n_dup:      Number of times each parameter set is simulated
		t_epochlong:total simulated time
		t_bold:      BOLD TR
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	d_t = 0.01
	# t_bold = BOLD_config.TR

	# Setting sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_num = parameter.shape[1]
	n_set = n_dup * n_num
	parameter = parameter.repeat(1, n_dup)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	S_g = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))
	dg = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001
	S_g[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	w_l = k_p.shape[0]
	d_w = math.sqrt(d_t) * torch.randn(n_dup, n_nodes, w_l + 1000)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_gammag(y_t, S_I, S_g, parameter, sc_mat)
		noise_level = d_w[:, :, i].repeat(1, 1, n_num).contiguous().view(
			-1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_gammag(y_t, S_I, S_g, parameter, sc_mat, nanlog=True)
		noise_level = d_w[:, :, i + 1000].repeat(1, 1,
												 n_num).contiguous().view(
													 -1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_multi_simulation_fusion_silence(parameter, sc_mat, n_dup, t_epochlong, t_bold):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated multiple times to get
	stable result
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G for glial
		sc_mat:     N*N structural connectivity matrix
		n_dup:      Number of times each parameter set is simulated
		t_epochlong:total simulated time
		t_bold:     BOLD TR
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	d_t = 0.01
	# t_bold = BOLD_config.TR

	# Setting sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_num = parameter.shape[1]
	n_set = n_dup * n_num
	parameter = parameter.repeat(1, n_dup)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	S_g = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))
	dg = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001
	S_g[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	w_l = k_p.shape[0]
	d_w = math.sqrt(d_t) * torch.randn(n_dup, n_nodes, w_l + 1000)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_silence_IG(y_t, S_I, S_g, parameter, sc_mat)
		noise_level = d_w[:, :, i].repeat(1, 1, n_num).contiguous().view(
			-1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_silence_IG(y_t, S_I, S_g, parameter, sc_mat, nanlog=True)
		noise_level = d_w[:, :, i + 1000].repeat(1, 1,
												 n_num).contiguous().view(
													 -1, n_nodes)
		y_t = y_t + d_y * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_I = S_I + dS_I * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		S_g = S_g + dg * d_t + w_coef * torch.transpose(noise_level, 0, 1)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_single_simulation_fusion_gammag(parameter, sc_mat, t_epochlong, d_t=0.01):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated one time
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
					parameter[5*N+1:6*N+1]: gamma_g for glial-neuro coupling
		sc_mat:     N*N structural connectivity matrix
		t_epochlong:total simulated time
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	t_bold = BOLD_config.TR

	# sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]
	n_set = parameter.shape[1]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	S_g = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))
	dg = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001
	S_g[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_gammag(y_t, S_I, S_g, parameter, sc_mat)
		y_t = y_t + d_y * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
		S_g = S_g + dg * d_t + w_coef * torch.randn(n_nodes,
													  n_set) * math.sqrt(d_t)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion_gammag(y_t, S_I, S_g, parameter, sc_mat, nanlog=True)
		random_num = torch.randn(n_nodes, n_set)
		y_t = y_t + d_y * d_t + w_coef * random_num * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * random_num * math.sqrt(d_t)
		S_g = S_g + dg * d_t + w_coef * random_num * math.sqrt(d_t)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_single_simulation_fusion(parameter, sc_mat, t_epochlong, d_t=0.01):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated one time
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		sc_mat:     N*N structural connectivity matrix
		t_epochlong:total simulated time
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	t_bold = BOLD_config.TR

	# sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]
	n_set = parameter.shape[1]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	S_g = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))
	dg = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001
	S_g[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion(y_t, S_I, S_g, parameter, sc_mat)
		y_t = y_t + d_y * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
		S_g = S_g + dg * d_t + w_coef * torch.randn(n_nodes,
													  n_set) * math.sqrt(d_t)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I, dg = CBIG_mfm_rfMRI_ode_inhibition_fusion(y_t, S_I, S_g, parameter, sc_mat, nanlog=True)
		random_num = torch.randn(n_nodes, n_set)
		y_t = y_t + d_y * d_t + w_coef * random_num * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * random_num * math.sqrt(d_t)
		S_g = S_g + dg * d_t + w_coef * random_num * math.sqrt(d_t)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_single_simulation_neuro(parameter, sc_mat, t_epochlong, d_t=0.01):
	'''
	Function used to generate the simulated BOLD signal using mean field
	model and hemodynamic model
	Each parameter set is ussed to simulated one time
	Args:
		parameter:  (N*5+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		sc_mat:     N*N structural connectivity matrix
		t_epochlong:total simulated time
	Returns:
		bold_d:     simulated BOLD signal
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Initializing system parameters
	kstart = 0.
	t_pre = 60 * 2
	kend = t_pre + t_epochlong
	t_bold = BOLD_config.TR

	# sampling ratio
	k_p = torch.arange(kstart, kend + d_t, d_t)
	n_nodes = sc_mat.shape[0]
	n_samples = k_p.shape[0]
	n_set = parameter.shape[1]

	# Initializing neural activity
	y_t = torch.zeros((n_nodes, n_set))
	S_I = torch.zeros((n_nodes, n_set))
	d_y = torch.zeros((n_nodes, n_set))
	dS_I = torch.zeros((n_nodes, n_set))

	# Initializing hemodynamic activity
	f_mat = torch.ones((n_nodes, n_set, 4))
	z_t = torch.zeros((n_nodes, n_set))
	f_t = torch.ones((n_nodes, n_set))
	v_t = torch.ones((n_nodes, n_set))
	q_t = torch.ones((n_nodes, n_set))
	f_mat[:, :, 0] = z_t
	y_t[:, :] = 0.001
	S_I[:, :] = 0.001

	# Wiener process
	w_coef = parameter[2 * n_nodes + 1:3 * n_nodes + 1, :] / math.sqrt(0.001)
	if w_coef.shape[0] == 1:
		w_coef = w_coef.repeat(n_nodes, 1)
	p_costant = 0.34
	v_0 = 0.02
	k_1 = 4.3 * 28.265 * 3 * 0.0331 * p_costant
	k_2 = 0.47 * 110 * 0.0331 * p_costant
	k_3 = 0.53
	count = 0
	y_bold = torch.zeros((n_nodes, n_set, int(n_samples / (t_bold / d_t) + 1)))

	# Warm up
	start = time.time()
	for i in range(1000):
		d_y, dS_I = CBIG_mfm_rfMRI_ode_inhibition_neuro(y_t, S_I, parameter, sc_mat)
		y_t = y_t + d_y * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * torch.randn(n_nodes,
													 n_set) * math.sqrt(d_t)
	nanlog_config.reset_log()
	# Main body: calculation
	for i in range(n_samples):
		d_y, dS_I = CBIG_mfm_rfMRI_ode_inhibition_neuro(y_t, S_I, parameter, sc_mat, nanlog=True)
		random_num = torch.randn(n_nodes, n_set)
		y_t = y_t + d_y * d_t + w_coef * random_num * math.sqrt(d_t)
		S_I = S_I + dS_I * d_t + w_coef * random_num * math.sqrt(d_t)
		d_f = CBIG_mfm_rfMRI_BW_ode(y_t, f_mat)
		f_mat = f_mat + d_f * d_t
		z_t, f_t, v_t, q_t = torch.chunk(f_mat, 4, dim=2)
		y_bold_temp = 100 / p_costant * v_0 * (
			k_1 * (1 - q_t) + k_2 * (1 - q_t / v_t) + k_3 * (1 - v_t))
		y_bold[:, :, count] = y_bold_temp[:, :, 0]
		count = count + ((i + 1) % (t_bold / d_t) == 0) * 1
	elapsed = time.time() - start
	print('The time used for calculating simulated BOLD signal is: ', elapsed)

	# Downsampling
	cut_index = int(t_pre / t_bold)
	bold_d = y_bold[:, :, cut_index + 1:y_bold.shape[2]]

	return bold_d

def CBIG_mfm_rfMRI_ode(y_t, parameter, sc_mat):
	'''
	This function is to calcualte the derivatives of synaptic gating
	variable S
	Args:
		y_t:        N*M matrix represents synaptic gating variable
					N is the number of ROI
					M is the number of candidate parameter sets
		parameter:  (N*3+1)*M matrix.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
		sc_mat:     N*N structural connectivity matrix
	Returns:
		dy:         N*M matrix represents derivatives of synaptic gating
		variable S
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Parameters for inputs and couplings
	number_roi = sc_mat.shape[0]
	J = 0.2609
	w = parameter[0:number_roi, :]
	G = parameter[2 * number_roi, :]
	I0 = parameter[number_roi:2 * number_roi, :]

	# Parameters for firing rate
	a = 270
	b = 108
	d = 0.154

	# Parameters for synaptic activity/currents
	tau_s = 0.1
	gamma_s = 0.641

	# Total input x
	x = J * w * y_t + J * G.repeat(number_roi, 1) * torch.mm(sc_mat, y_t) + I0

	# Population firing rate
	H = (a * x - b) / (1 - torch.exp(-d * (a * x - b)))

	# Synaptic activity
	dy = -1 / tau_s * y_t + gamma_s * (1 - y_t) * H

	return dy

def CBIG_mfm_rfMRI_ode_inhibition_neuro(y_t, S_I, parameter, sc_mat, nanlog=False):
	'''
	This function is to calcualte the derivatives of synaptic gating
	variable S
	Args:
		y_t:        N*M matrix represents synaptic gating variable for excitatory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_I:        N*M matrix represents synaptic gating variable for inhibitory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		parameter:  (N*4+1)*M matrix.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w_E
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
		sc_mat:     N*N structural connectivity matrix
	Returns:
		dy:         N*M matrix represents derivatives of synaptic gating
		variable S
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Parameters for inputs and couplings
	number_roi = sc_mat.shape[0]
	J_E= 0.15
	w_E = parameter[0:number_roi, :]
	G = parameter[2 * number_roi, :]
	I0 = parameter[number_roi:2 * number_roi, :]
	w_I = parameter[number_roi * 3 + 1:number_roi * 4 + 1, :]


	# Parameters for firing rate
	a_E = 310
	b_E = 125
	d_E = 0.16
	a_I = 615
	b_I = 177
	d_I = 0.087
	# Parameters for synaptic activity/currents
	tau_E = 0.1
	tau_I = 0.01
	gamma_s = 0.641

	# Total input x
	x_E = J_E * w_E * y_t + J_E * G.repeat(number_roi, 1) * torch.mm(sc_mat, y_t) + I0 - S_I
	x_I = J_E * w_I * y_t - S_I + 0.7*I0
	# Population firing rate
	K = -d_E * (a_E * x_E - b_E)	### 沒用上
	K_2_n = K.cpu().numpy()			### 沒用上
	idx = np.argwhere(K_2_n == 0)	### 沒用上
	H_E = (a_E * x_E - b_E) / (1 - torch.exp(-d_E * (a_E * x_E - b_E)) + 1e-8)
	H_I = (a_I * x_I - b_I) / (1 - torch.exp(-d_I * (a_I * x_I - b_I)) + 1e-8)
	if nanlog:
		if torch.isnan(H_E).any():
			nanlog_config.set_log(1,0)
		if torch.isnan(H_I).any():
			nanlog_config.set_log(0,1)
	# Synaptic activity
	dy = -1 / tau_E * y_t + gamma_s * (1 - y_t) * H_E
	dS_I = -1 / tau_I * S_I +  H_I
	return dy, dS_I


def CBIG_mfm_rfMRI_ode_inhibition_fusion(y_t, S_I, S_g, parameter, sc_mat, nanlog=False):
	'''
	This function is to calcualte the derivatives of synaptic gating
	variable S
	Args:
		y_t:        N*M matrix represents synaptic gating variable for excitatory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_I:        N*M matrix represents synaptic gating variable for inhibitory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_g:        N*M matrix represents synaptic gating variable for glials
					N is the number of ROI
					M is the number of candidate parameter sets
		parameter:  (N*5+1)*M matrix.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w_E
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		sc_mat:     N*N structural connectivity matrix
	Returns:
		dy:         N*M matrix represents derivatives of synaptic gating
		variable S
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Parameters for inputs and couplings
	number_roi = sc_mat.shape[0]
	J_E = 0.15
	w_E = parameter[0:number_roi, :]
	G = parameter[2 * number_roi, :]
	I0 = parameter[number_roi:2 * number_roi, :]
	w_I = parameter[number_roi * 3 + 1:number_roi * 4 + 1, :]
	w_G = parameter[number_roi * 4 + 1:number_roi * 5 + 1, :]

	# Parameters for firing rate
	a_E = 310
	b_E = 125
	d_E = 0.16
	a_I = 615
	b_I = 177
	d_I = 0.087
	a_G = 9.5791 # -323.8
	b_G = 0.0105 # 0.008935
	d_G = 95.1605
	# Parameters for synaptic activity/currents
	tau_E = 0.1
	tau_I = 0.01
	tau_G = glia_config.tau_G	# origin 0.2 to 0.01
	gamma_s = 0.641
	# Parameters for glial-neuron coupling
	gamma_g = glia_config.gamma_g
	xi = glia_config.xi

	# Total input x
	x_E = J_E * w_E * y_t + J_E * G.repeat(number_roi, 1) * torch.mm(sc_mat, y_t) + I0 - S_I
	x_I = J_E * w_I * y_t - S_I + 0.7 * I0
	x_G = J_E * w_G * y_t + S_I + 0.2 * I0
	# Population firing rate
	K = -d_E * (a_E * x_E - b_E)
	K_2_n = K.cpu().numpy()
	idx = np.argwhere(K_2_n == 0)
	H_E = (a_E * x_E - b_E) / (1 - torch.exp(-d_E * (a_E * x_E - b_E)) + 1e-8)
	H_I = (a_I * x_I - b_I) / (1 - torch.exp(-d_I * (a_I * x_I - b_I)) + 1e-8)
	H_G =  a_G / (1 + torch.exp(-d_G * (x_G - b_G)))
	# H_G =  a_G * x_G - b_G
	if nanlog:
		if torch.isnan(H_E).any():
			nanlog_config.set_log(1,0)
		if torch.isnan(H_I).any():
			nanlog_config.set_log(0,1)
	# Synaptic activity
	dy = -1 / tau_E * y_t + gamma_s * (1 - y_t) * H_E + gamma_g * (xi - y_t) * S_g
	dS_I = -1 / tau_I * S_I + H_I
	dg = -1/tau_G * S_g + H_G
	return dy, dS_I, dg

def CBIG_mfm_rfMRI_ode_inhibition_fusion_gammag(y_t, S_I, S_g, parameter, sc_mat, nanlog=False):
	'''
	This function is to calcualte the derivatives of synaptic gating
	variable S
	Args:
		y_t:        N*M matrix represents synaptic gating variable for excitatory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_I:        N*M matrix represents synaptic gating variable for inhibitory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_g:        N*M matrix represents synaptic gating variable for glials
					N is the number of ROI
					M is the number of candidate parameter sets
		parameter:  (N*5+1)*M matrix.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w_E
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
					parameter[5*N+1:6*N+1]: gamma_g for glial-neuron coupling
		sc_mat:     N*N structural connectivity matrix
	Returns:
		dy:         N*M matrix represents derivatives of synaptic gating
		variable S
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Parameters for inputs and couplings
	number_roi = sc_mat.shape[0]
	J_E = 0.15
	w_E = parameter[0:number_roi, :]
	G = parameter[2 * number_roi, :]
	I0 = parameter[number_roi:2 * number_roi, :]
	w_I = parameter[number_roi * 3 + 1:number_roi * 4 + 1, :]
	w_G = parameter[number_roi * 4 + 1:number_roi * 5 + 1, :]
	gamma_g = parameter[number_roi * 5 + 1:number_roi * 6 + 1, :]

	# Parameters for firing rate
	a_E = 310
	b_E = 125
	d_E = 0.16
	a_I = 615
	b_I = 177
	d_I = 0.087
	a_G = 9.5791 # -323.8
	b_G = 0.0105 # 0.008935
	d_G = 95.1605
	# Parameters for synaptic activity/currents
	tau_E = 0.1
	tau_I = 0.01
	tau_G = glia_config.tau_G	# origin 0.2 to 0.01
	gamma_s = 0.641
	# Parameters for glial-neuron coupling
	# gamma_g = glia_config.gamma_g
	xi = glia_config.xi

	# Total input x
	x_E = J_E * w_E * y_t + J_E * G.repeat(number_roi, 1) * torch.mm(sc_mat, y_t) + I0 - S_I
	x_I = J_E * w_I * y_t - S_I + 0.7 * I0
	x_G = J_E * w_G * y_t + S_I + 0.2 * I0
	# Population firing rate
	K = -d_E * (a_E * x_E - b_E)
	K_2_n = K.cpu().numpy()
	idx = np.argwhere(K_2_n == 0)
	H_E = (a_E * x_E - b_E) / (1 - torch.exp(-d_E * (a_E * x_E - b_E)) + 1e-8)
	H_I = (a_I * x_I - b_I) / (1 - torch.exp(-d_I * (a_I * x_I - b_I)) + 1e-8)
	H_G =  a_G / (1 + torch.exp(-d_G * (x_G - b_G)))
	# H_G =  a_G * x_G - b_G
	if nanlog:
		if torch.isnan(H_E).any():
			nanlog_config.set_log(1,0)
		if torch.isnan(H_I).any():
			nanlog_config.set_log(0,1)
	# Synaptic activity
	dy = -1 / tau_E * y_t + gamma_s * (1 - y_t) * H_E + gamma_g * (xi - y_t) * S_g
	dS_I = -1 / tau_I * S_I + H_I
	dg = -1/tau_G * S_g + H_G
	return dy, dS_I, dg

def CBIG_mfm_rfMRI_ode_inhibition_fusion_silence_IG(y_t, S_I, S_g, parameter, sc_mat, nanlog=False):
	'''
	This function is to calcualte the derivatives of synaptic gating
	variable S
	Args:
		y_t:        N*M matrix represents synaptic gating variable for excitatory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_I:        N*M matrix represents synaptic gating variable for inhibitory neurons
					N is the number of ROI
					M is the number of candidate parameter sets
		S_g:        N*M matrix represents synaptic gating variable for glials
					N is the number of ROI
					M is the number of candidate parameter sets
		parameter:  (N*5+1)*M matrix.
					Each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w_E
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		sc_mat:     N*N structural connectivity matrix
	Returns:
		dy:         N*M matrix represents derivatives of synaptic gating
		variable S
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Parameters for inputs and couplings
	number_roi = sc_mat.shape[0]
	J_E = 0.15
	w_E = parameter[0:number_roi, :]
	G = parameter[2 * number_roi, :]
	I0 = parameter[number_roi:2 * number_roi, :]
	w_I = parameter[number_roi * 3 + 1:number_roi * 4 + 1, :]
	w_G = parameter[number_roi * 4 + 1:number_roi * 5 + 1, :]

	# Parameters for firing rate
	a_E = 310
	b_E = 125
	d_E = 0.16
	a_I = 615
	b_I = 177
	d_I = 0.087
	a_G = 9.5791 # -323.8
	b_G = 0.0105 # 0.008935
	d_G = 95.1605
	# Parameters for synaptic activity/currents
	tau_E = 0.1
	tau_I = 0.01
	tau_G = glia_config.tau_G	# origin 0.2 to 0.01
	gamma_s = 0.641
	# Parameters for glial-neuron coupling
	gamma_g = glia_config.gamma_g
	xi = glia_config.xi

	# Total input x
	x_E = J_E * w_E * y_t + J_E * G.repeat(number_roi, 1) * torch.mm(sc_mat, y_t) + I0 - S_I
	x_I = J_E * w_I * y_t - S_I + 0.7 * I0
	x_G = 0
	# Population firing rate
	K = -d_E * (a_E * x_E - b_E)
	K_2_n = K.cpu().numpy()
	idx = np.argwhere(K_2_n == 0)
	H_E = (a_E * x_E - b_E) / (1 - torch.exp(-d_E * (a_E * x_E - b_E)) + 1e-8)
	H_I = (a_I * x_I - b_I) / (1 - torch.exp(-d_I * (a_I * x_I - b_I)) + 1e-8)
	H_G =  a_G / (1 + torch.exp(-d_G * (x_G - b_G)))
	# H_G =  a_G * x_G - b_G
	if nanlog:
		if torch.isnan(H_E).any():
			nanlog_config.set_log(1,0)
		if torch.isnan(H_I).any():
			nanlog_config.set_log(0,1)
	# Synaptic activity
	dy = -1 / tau_E * y_t + gamma_s * (1 - y_t) * H_E + gamma_g * (xi - y_t) * S_g
	dS_I = -1 / tau_I * S_I + H_I
	dg = -1/tau_G * S_g + H_G
	return dy, dS_I, dg

def CBIG_mfm_rfMRI_BW_ode(y_t, F):
	'''
	This fucntion is to implement the hemodynamic model
	Args:
		y_t:        N*M matrix represents synaptic gating variable
					N is the number of ROI
					M is the number of candidate parameter sets
		F:          Hemodynamic activity variables
	Returns:
		dF:         Derivatives of hemodynamic activity variables
	'''

	torch.set_default_tensor_type('torch.cuda.FloatTensor')

	# Hemodynamic model parameters
	beta = 0.65
	gamma = 0.41
	tau = 0.98
	alpha = 0.33
	p_constant = 0.34
	n_nodes = y_t.shape[0]
	n_set = y_t.shape[1]

	# Calculate derivatives
	dF = torch.zeros((n_nodes, n_set, 4))
	dF[:, :, 0] = y_t - beta * F[:, :, 0] - gamma * (F[:, :, 1] - 1)
	dF[:, :, 1] = F[:, :, 0]
	dF[:, :, 2] = 1 / tau * (F[:, :, 1] - F[:, :, 2]**(1 / alpha))
	dF[:, :, 3] = 1 / tau * (F[:, :, 1] / p_constant * (1 - (1 - p_constant)**
														(1 / F[:, :, 1])) -
							 F[:, :, 3] / F[:, :, 2] * F[:, :, 2]**(1 / alpha))
	return dF

'''FCcorrelation'''
def CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup):
	'''
	This function is to calculate the FC correlation cost for multiple
	simulation
	BOLD signal results
	Args:
		emp_fc:     N*N group level FC matrix
					N is number of ROI
		bold_d:     simulated BOLD signal
		n_dup:      Number of times each parameter set is simulated
	Returns:
		corr_cost:   FC correlation cost
	'''

	fc_timestart = time.time()

	# Calculate vectored simulated FC
	n_set = bold_d.shape[1]
	n_num = int(n_set / n_dup)
	n_nodes = emp_fc.shape[0]
	fc_mask = torch.triu(torch.ones(n_nodes, n_nodes), 1) == 1
	vect_len = int(n_nodes * (n_nodes - 1) / 2)
	sim_fc_vector = torch.zeros(n_set, vect_len)
	for i in range(n_set):
		sim_fc = torch_corr(bold_d[:, i, :])
		sim_fc_vector[i, :] = sim_fc[fc_mask]

	# Average the simulated FCs with same parameter set
	sim_fc_vector[sim_fc_vector != sim_fc_vector] = 0
	sim_fc_num = torch.zeros(n_num, vect_len)
	sim_fc_den = torch.zeros(n_num, 1)
	for k in range(n_dup):
		sim_fc_num = sim_fc_num + sim_fc_vector[k * n_num:(k + 1) * n_num, :]
		sim_fc_den = sim_fc_den + (
			sim_fc_vector[k * n_num:(k + 1) * n_num, 0:1] != 0).float()
	sim_fc_den[sim_fc_den == 0] = np.nan
	sim_fc_ave = sim_fc_num / sim_fc_den

	# Calculate FC correlation
	emp_fcm = emp_fc[fc_mask].repeat(n_num, 1)
	sim_fc_ave_fisherz = torch_arctanh(sim_fc_ave)
	emp_fcm_fisherz = torch_arctanh(emp_fcm)
	corr_mass = torch_corr2(sim_fc_ave_fisherz, emp_fcm_fisherz)	## size (n_num, n_num)
	# print('Nan in corr_mass: ', torch.isnan(corr_mass).sum())
	corr_cost = torch.diag(corr_mass)
	corr_cost = corr_cost.cpu().numpy()
	corr_cost = 1 - corr_cost
	corr_cost[np.isnan(corr_cost)] = 10

	fc_elapsed = time.time() - fc_timestart
	# print('Time using for calcualting FC correlation cost: ', fc_elapsed)

	return corr_cost	## size (n_num, 1)

def CBIG_FCcorrelation_single_simulation(emp_fc, bold_d, n_dup):
	'''
	This function is to calculate the FC correlation cost for single
	simulation
	BOLD signal result
	Args:
		emp_fc:     N*N group level FC matrix
					N is number of ROI
		bold_d:     simulated BOLD signal
	Returns:
		corr_cost:   FC correlation cost
	'''

	fc_timestart = time.time()

	# Calculate vectored simulated FC
	n_set = bold_d.shape[1]
	n_nodes = emp_fc.shape[0]
	fc_mask = torch.triu(torch.ones(n_nodes, n_nodes), 1) == 1
	vect_len = int(n_nodes * (n_nodes - 1) / 2)
	sim_fc_vector = torch.zeros(n_set, vect_len)
	for i in range(n_set):
		sim_fc = torch_corr(bold_d[:, i, :])
		sim_fc_vector[i, :] = sim_fc[fc_mask]

	# Calculate FC correlation
	sim_fc_numpy = sim_fc_vector.cpu().numpy()
	emp_fc_numpy = emp_fc[fc_mask].cpu().numpy()
	time_dup = int(n_set / n_dup)
	corr_cost = np.zeros(time_dup)

	for t in range(time_dup):
		sim_fc_numpy_temp = sim_fc_numpy[t * n_dup:(t + 1) * n_dup, :]
		sim_fc_mean = np.nanmean(sim_fc_numpy_temp, 0)
		corrmean_temp = np.corrcoef(
			np.arctanh(sim_fc_mean), np.arctanh(emp_fc_numpy))
		corr_cost[t] = 1 - corrmean_temp[1, 0]

	fc_elapsed = time.time() - fc_timestart
	# print('Time using for calcualting FC correlation cost: ', fc_elapsed)
	return corr_cost

'''FCDKSstat'''
def CBIG_FCDKSstat_multi_simulation(emp_ks, bold_d, n_dup):
	'''
	This function is to calculate the FCD KS statistics cost for
	multiple simulation
	BOLD signal results
	Args:
		emp_ks:     Group level KS statistics for empirical data
		bold_d:     simulated BOLD signal
		n_dup:      Number of times each parameter set is simulated
	Returns:
		ks_cost:   FCD KS statistics cost
	'''

	fcd_timestart = time.time()

	# Initializing the FC and FCD masks
	n_set = bold_d.shape[1]
	n_num = int(n_set / n_dup)
	n_nodes = bold_d.shape[0]
	window_size = system_config.window_size
	n_frame = BOLD_config.n_frame
	time_lengh = n_frame - window_size + 1
	sub_num = 10
	resid_num = n_set % sub_num
	fc_edgenum = int(n_nodes * (n_nodes - 1) / 2)
	fc_mask = torch.triu(torch.ones(n_nodes, n_nodes), 1) == 1
	fc_maskm = torch.zeros(n_nodes * sub_num,
						   n_nodes * sub_num).type(torch.cuda.ByteTensor)
	for i in range(sub_num):
		fc_maskm[n_nodes * i:n_nodes * (i + 1), n_nodes * i:n_nodes *
				 (i + 1)] = fc_mask

	fc_mask_resid = torch.zeros(n_nodes * resid_num, n_nodes * resid_num).type(
		torch.cuda.ByteTensor)
	for i in range(resid_num):
		fc_mask_resid[n_nodes * i:n_nodes * (i + 1), n_nodes * i:n_nodes *
					  (i + 1)] = fc_mask

	fcd_mask = torch.triu(torch.ones(time_lengh, time_lengh), 1) == 1

	# Calculating CDF for simualted FCD matrices
	fcd_hist = torch.ones(10000, n_set).cpu()
	fc_mat = torch.zeros(fc_edgenum, sub_num, time_lengh)
	batch_num = math.floor(n_set / sub_num)
	fc_resid = torch.zeros(fc_edgenum, resid_num, time_lengh)

	for b in range(batch_num):
		bold_temp = bold_d[:, b * sub_num:(b + 1) * sub_num, :]
		bold_tempm = bold_temp.transpose(0, 1).contiguous().view(-1, n_frame)
		for i in range(0, time_lengh):
			bold_fc = torch_corr(bold_tempm[:, i:i + window_size])
			cor_temp = bold_fc[fc_maskm]
			fc_mat[:, :, i] = torch.transpose(
				cor_temp.view(sub_num, fc_edgenum), 0, 1)

		for j in range(0, sub_num):
			fcd_temp = torch_corr(torch.transpose(fc_mat[:, j, :], 0, 1))
			fcd_hist[:, j + b * sub_num] = torch.histc(
				fcd_temp[fcd_mask].cpu(), 10000, (0.0001 - 1), 1)

	if resid_num != 0:
		bold_temp = bold_d[:, batch_num * sub_num:n_set, :]
		bold_tempm = bold_temp.transpose(0, 1).contiguous().view(-1, n_frame)
		for i in range(time_lengh):
			bold_fc = torch_corr(bold_tempm[:, i:i + window_size])
			cor_temp = bold_fc[fc_mask_resid]
			fc_resid[:, :, i] = torch.transpose(
				cor_temp.view(resid_num, fc_edgenum), 0, 1)

		for j in range(resid_num):
			fcd_temp = torch_corr(torch.transpose(fc_resid[:, j, :], 0, 1))
			fcd_hist[:, j + sub_num * batch_num] = torch.histc(
				fcd_temp[fcd_mask].cpu(), 10000, (0.0001 - 1), 1)

	fcd_histcum = np.cumsum(fcd_hist.numpy(), 0)
	fcd_histcumM = fcd_histcum.copy()
	fcd_histcumM[:, fcd_histcum[-1, :] != emp_ks[-1, 0]] = 0

	# Calculating KS statistics cost
	fcd_histcum_temp = np.zeros((10000, n_num))
	fcd_histcum_num = np.zeros((1, n_num))
	for k in range(n_dup):
		fcd_histcum_temp = fcd_histcum_temp + \
			fcd_histcumM[:, k * n_num:(k + 1) * n_num]
		fcd_histcum_num = fcd_histcum_num + (
			fcd_histcumM[-1, k * n_num:(k + 1) * n_num] == emp_ks[-1, 0])
	fcd_histcum_ave = fcd_histcum_temp / fcd_histcum_num
	ks_diff = np.abs(fcd_histcum_ave - np.tile(emp_ks, [1, n_num]))
	ks_cost = ks_diff.max(0) / emp_ks[-1, 0]
	ks_cost[fcd_histcum_ave[-1, :] != emp_ks[-1, 0]] = 10

	fcd_elapsed = time.time() - fcd_timestart
	# print('Time using for calcualting FCD KS statistics cost: ', fcd_elapsed)
	return ks_cost

def CBIG_FCDKSstat_single_simulation(emp_ks, bold_d, n_dup, window_size=system_config.window_size):
	'''
	This function is to calculate the FCD KS statistics cost for single
	simulation
	BOLD signal results
	Args:
		emp_ks:     Group level KS statistics for empirical data
		bold_d:     simulated BOLD signal
	Returns:
		ks_cost:    FCD KS statistics cost
	'''

	fcd_timestart = time.time()

	# Initializing the FC and FCD masks
	n_set = bold_d.shape[1]
	n_nodes = bold_d.shape[0]
	n_frame = BOLD_config.n_frame
	time_lengh = n_frame - window_size + 1
	sub_num = 10
	resid_num = n_set % sub_num
	fc_edgenum = int(n_nodes * (n_nodes - 1) / 2)
	fc_mask = torch.triu(torch.ones(n_nodes, n_nodes), 1) == 1
	fc_maskm = torch.zeros(n_nodes * sub_num,
						   n_nodes * sub_num).type(torch.cuda.ByteTensor)

	for i in range(sub_num):
		fc_maskm[n_nodes * i:n_nodes * (i + 1), n_nodes * i:n_nodes *
				 (i + 1)] = fc_mask

	fc_mask_resid = torch.zeros(n_nodes * resid_num, n_nodes * resid_num).type(
		torch.cuda.ByteTensor)
	for i in range(resid_num):
		fc_mask_resid[n_nodes * i:n_nodes * (i + 1), n_nodes * i:n_nodes *
					  (i + 1)] = fc_mask

	fcd_mask = torch.triu(torch.ones(time_lengh, time_lengh), 1) == 1

	# Calculating CDF for simualted FCD matrices
	fcd_hist = torch.ones(10000, n_set).cpu()
	fc_mat = torch.zeros(fc_edgenum, sub_num, time_lengh)
	batch_num = int(n_set / sub_num)
	fc_resid = torch.zeros(fc_edgenum, resid_num, time_lengh)

	for b in range(batch_num):
		bold_temp = bold_d[:, b * sub_num:(b + 1) * sub_num, :]
		bold_tempm = bold_temp.transpose(0, 1).contiguous().view(-1, n_frame)
		for i in range(0, time_lengh):
			bold_fc = torch_corr(bold_tempm[:, i:i + window_size])
			cor_temp = bold_fc[fc_maskm]
			fc_mat[:, :, i] = torch.transpose(
				cor_temp.view(sub_num, fc_edgenum), 0, 1)

		for j in range(0, sub_num):
			fcd_temp = torch_corr(torch.transpose(fc_mat[:, j, :], 0, 1))
			fcd_hist[:, j + b * sub_num] = torch.histc(
				fcd_temp[fcd_mask].cpu(), 10000, (0.0001 - 1), 1)

	if resid_num != 0:
		bold_temp = bold_d[:, batch_num * sub_num:n_set, :]
		bold_tempm = bold_temp.transpose(0, 1).contiguous().view(-1, n_frame)
		for i in range(time_lengh):
			bold_fc = torch_corr(bold_tempm[:, i:i + window_size])
			cor_temp = bold_fc[fc_mask_resid]
			fc_resid[:, :, i] = torch.transpose(
				cor_temp.view(resid_num, fc_edgenum), 0, 1)

		for j in range(resid_num):
			fcd_temp = torch_corr(torch.transpose(fc_resid[:, j, :], 0, 1))
			fcd_hist[:, j + sub_num * batch_num] = torch.histc(
				fcd_temp[fcd_mask].cpu(), 10000, (0.0001 - 1), 1)

	fcd_histcum = np.cumsum(fcd_hist.numpy(), 0)

	# Calculating KS statistics cost
	time_dup = int(n_set / n_dup)
	ks_cost = np.zeros(time_dup)
	for t in range(time_dup):
		fcd_hist_temp = fcd_histcum[:, t * n_dup:(t + 1) * n_dup]
		fcd_histcum_nn = fcd_hist_temp[:, fcd_hist_temp[-1, :] ==
									   emp_ks[-1, 0]]
		fcd_hist_mean = np.mean(fcd_histcum_nn, 1)
		ks_cost[t] = np.max(
			np.abs(fcd_hist_mean - emp_ks[:, 0]) / emp_ks[-1, 0])

	fcd_elapsed = time.time() - fcd_timestart
	# print('Time using for cost function: ', fcd_elapsed)
	return ks_cost

def torch_corr(A):
	'''
	Self implemented correlation function used for GPU
	'''

	Amean = torch.mean(A, 1)
	Ax = A - torch.transpose(Amean.repeat(A.shape[1], 1), 0, 1)
	Astd = torch.mean(Ax**2, 1)
	Amm = torch.mm(Ax, torch.transpose(Ax, 0, 1)) / A.shape[1]
	Aout = torch.sqrt(torch.ger(Astd, Astd))
	Acor = Amm / Aout
	return Acor


def torch_corr2(A, B):
	'''
	Self implemented correlation function used for GPU
	'''

	Amean = torch.mean(A, 1)
	Ax = A - torch.transpose(Amean.repeat(A.shape[1], 1), 0, 1)
	Astd = torch.mean(Ax**2, 1)
	# print('Zero in sim_fc_std: ' + str(torch.sum(Astd == 0)))
	Bmean = torch.mean(B, 1)
	Bx = B - torch.transpose(Bmean.repeat(B.shape[1], 1), 0, 1)
	Bstd = torch.mean(Bx**2, 1)
	# print('Zero in emp_fc_std: ' + str(torch.sum(Bstd == 0)))	# empirical
	numerator = torch.mm(Ax, torch.transpose(Bx, 0, 1)) / A.shape[1]
	denominator = torch.sqrt(torch.ger(Astd, Bstd))
	torch_cor = numerator / denominator
	return torch_cor


def torch_arctanh(A):
	arctanh = 0.5 * torch.log((1 + A) / (1 - A))
	return arctanh


'''********************  Functions for computing FC & FCD costs
*************************'''

def CBIG_combined_cost_train_fusion_gammag(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on training
	data
	Args:
		parameter:  (N*4+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
					parameter[5*N+1:6*N+1]: gamma_g for glial-neuron coupling
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading training data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(training_config.FCD_training)
	emp_fcd = np.array(emp_fcd[training_config.FCD_name])

	sc_mat_raw = csv_matrix_read(training_config.SC_training)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(training_config.FC_training)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_fusion_gammag(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_train_fusion(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on training
	data
	Args:
		parameter:  (N*4+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading training data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(training_config.FCD_training)
	emp_fcd = np.array(emp_fcd[training_config.FCD_name])

	sc_mat_raw = csv_matrix_read(training_config.SC_training)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(training_config.FC_training)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_fusion(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_train_neuro(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on training
	data
	Args:
		parameter:  (N*4+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading training data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(training_config.FCD_training)
	emp_fcd = np.array(emp_fcd[training_config.FCD_name])

	sc_mat_raw = csv_matrix_read(training_config.SC_training)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(training_config.FC_training)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()
	# print('bold sim start')  ###
	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_neuro(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)
	# print('bold sim end')  ###
	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_validation_fusion_gammag(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on
	validation data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
					parameter[5*N+1:6*N+1]: gamma_g for glial-neuron coupling
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(validation_config.FCD_validation)
	emp_fcd = np.array(emp_fcd[validation_config.FCD_name])

	sc_mat_raw = csv_matrix_read(validation_config.SC_validation)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(validation_config.FC_validation)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_fusion_gammag(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)	## todo

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_validation_fusion(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on
	validation data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
					parameter[4*N+1:5*N+1]: recurrent strength w_G
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(validation_config.FCD_validation)
	emp_fcd = np.array(emp_fcd[validation_config.FCD_name])

	sc_mat_raw = csv_matrix_read(validation_config.SC_validation)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(validation_config.FC_validation)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_fusion(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)	## todo

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_validation_neuro(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on
	validation data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
					parameter[3*N+1:4*N+1]: recurrent strength w_I
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(validation_config.FCD_validation)
	emp_fcd = np.array(emp_fcd[validation_config.FCD_name])

	sc_mat_raw = csv_matrix_read(validation_config.SC_validation)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(validation_config.FC_validation)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_multi_simulation_neuro(parameter, sc_mat, n_dup, BOLD_config.timelong, BOLD_config.TR)	## todo

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_multi_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_multi_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_test_fusion_gammag(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on test data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = np.tile(parameter, [1, n_dup])
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(test_config.FCD_test)
	emp_fcd = np.array(emp_fcd[test_config.FCD_name])

	sc_mat_raw = csv_matrix_read(test_config.SC_test)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(test_config.FC_test)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_single_simulation_fusion_gammag(parameter, sc_mat, BOLD_config.timelong)

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_single_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_single_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_test_fusion(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on test data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = np.tile(parameter, [1, n_dup])
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(test_config.FCD_test)
	emp_fcd = np.array(emp_fcd[test_config.FCD_name])

	sc_mat_raw = csv_matrix_read(test_config.SC_test)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(test_config.FC_test)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_single_simulation_fusion(parameter, sc_mat, BOLD_config.timelong)

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_single_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_single_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def CBIG_combined_cost_test_neuro(parameter, n_dup):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on test data
	Args:
		parameter:  (N*3+1)*M matrix.
					N is the number of ROI
					M is the number of candidate parameter sets.
					each column of matrix presents a parameter set, where:
					parameter[0:N]: recurrent strength w
					parameter[N:2*N]: external input I
					parameter[2*N]: Gloable constant G
					parameter[2*N+1:3*N+1]: noise amplitude sigma
		n_dup:      number of times each parameter set is simulated
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
		corr_cost:  FC correlation cost
		ks_cost:    FCD KS statistics cost
	'''

	# Loading validation data
	parameter = np.tile(parameter, [1, n_dup])
	parameter = torch.from_numpy(parameter).type(torch.FloatTensor).cuda()

	emp_fcd = sio.loadmat(test_config.FCD_test)
	emp_fcd = np.array(emp_fcd[test_config.FCD_name])

	sc_mat_raw = csv_matrix_read(test_config.SC_test)
	sc_mat = sc_mat_raw / sc_mat_raw.max() * 0.2
	sc_mat = torch.from_numpy(sc_mat).type(torch.FloatTensor).cuda()

	emp_fc = csv_matrix_read(test_config.FC_test)
	emp_fc = torch.from_numpy(emp_fc).type(torch.FloatTensor).cuda()

	# Calculating simualted BOLD signal using MFM
	bold_d = CBIG_mfm_single_simulation_neuro(parameter, sc_mat, BOLD_config.timelong)

	# Calculating FC correlation cost
	fc_cost = CBIG_FCcorrelation_single_simulation(emp_fc, bold_d, n_dup)

	# Calculating FCD KS statistics cost
	fcd_cost = CBIG_FCDKSstat_single_simulation(emp_fcd, bold_d, n_dup)

	# Calculating total cost
	# total_cost = fc_cost + fcd_cost
	total_cost = total_cost_calculator(fc_cost, fcd_cost)

	return total_cost, fc_cost, fcd_cost

def total_cost_calculator(fc_cost, fcd_cost):
	'''
	This function is implemented to calcualted the FC correlation and
	FCD KS
	statistics combined cost for input parameter sets based on test data
	Args:
		fc_cost:    FC correlation cost
		fcd_cost:   FCD KS statistics cost
		fc_weight:  weight of FC correlation cost
		fcd_weight: weight of FCD KS statistics cost
	Returns:
		total_cost: summation of FC correlation cost and FCD KS
		statistics cost
	'''
	if system_config.hierarchy_cost_mode == True:
		# total_cost = w_fc * max(0, fc_cost-threshold) + w_fcd * fcd_cost
		theta_FC = system_config.FC_cost_threshold
    	# 使用np.maximum进行逐元素比较
		fc_cost_clipped = np.maximum(fc_cost, theta_FC)
    	# 然后应用您原有的加权公式
		total_cost = training_config.FC_cost_weight * fc_cost_clipped + training_config.FCD_cost_weight * fcd_cost
	else:
		total_cost = training_config.FC_cost_weight * fc_cost + training_config.FCD_cost_weight * fcd_cost
	return total_cost

def csv_matrix_read(filename):
	csv_file = open(filename, "r")
	read_handle = csv.reader(csv_file)
	out_list = []
	R = 0
	for row in read_handle:
		out_list.append([])
		for col in row:
			out_list[R].append(float(col))
		R = R + 1
	out_array = np.array(out_list)
	csv_file.close()
	return out_array

class nanlog_config:
    HE_has_nan = 0
    HI_has_nan = 0

    def reset_log():
        nanlog_config.HE_has_nan = 0
        nanlog_config.HI_has_nan = 0

    def set_log(HE_has_nan=0, HI_has_nan=0):
        if nanlog_config.HE_has_nan == 0 | nanlog_config.HI_has_nan == 0:
            print('First nan detected, logging started.')
        nanlog_config.HE_has_nan += HE_has_nan
        nanlog_config.HI_has_nan += HI_has_nan

    def print_log(save_file=None):
        if nanlog_config.HE_has_nan==0 & nanlog_config.HI_has_nan==0:
            return
        print('HE_has_nan: ', nanlog_config.HE_has_nan)
        print('HI_has_nan: ', nanlog_config.HI_has_nan)

        xmin = np.array([nanlog_config.HE_has_nan, nanlog_config.HI_has_nan])
        if save_file is not None:
            np.savetxt(save_file, xmin, delimiter=',')
        return nanlog_config.HE_has_nan, nanlog_config.HI_has_nan

