# /usr/bin/env python
'''
Written by Kong Xiaolu and CBIG under MIT license:
https://github.com/ThomasYeoLab/CBIG/blob/master/LICENSE.md
'''

import os
import numpy as np
import time
import torch
import pMFM_basic_functions_main as fc
from pMFM_config import system_config, training_config, validation_config, plan
import warnings

def CBIG_mfm_validation_main_fusion_para(set_range=range(1, 11),gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Fusion Para', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    highest_order = 1
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0]
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]

    amatrix = np.zeros((n_node, highest_order + 1))
    bmatrix = np.zeros((n_node, highest_order + 1))
    for i in range(highest_order + 1):
        amatrix[:, i] = myelin_data**(i)
        bmatrix[:, i] = gradient_data**(i)
    template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))

    N_para = 2 * highest_order + 1

    # Setting hyper-parameters
    n_trial = validation_config.n_trial  # 并行处理，500/n_trial个参数集模型同时跑验证
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Fusion Para Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 5 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w = template_mat @ x_mass[0:N_para, :]
        para_I = template_mat @ x_mass[N_para:2 *
                                       (N_para), :]
        para_sigma = template_mat @ x_mass[2 * (N_para) +
                                           1:3 * (N_para) + 1, :]
        para_W_I = template_mat @ x_mass[3 * (N_para) +
                                           1:4 * (N_para) + 1, :]
        para_W_G = template_mat @ x_mass[4 * (N_para) +
                                         1:x_mass.shape[0], :]
        arx_mass = np.concatenate(
            (para_w, para_I, x_mass[2 * (N_para):2 *
                                    (N_para) + 1, :],
             para_sigma,para_W_I, para_W_G), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_fusion(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Fusion Para Done', flush=True)


def CBIG_mfm_validation_main_fusion_heter(set_range=range(1,11), gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Fusion Heter', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    n_node = system_config.n_roi
    # amatrix = np.zeros((n_node, highest_order + 1))
    # bmatrix = np.zeros((n_node, highest_order + 1))
    # for i in range(highest_order + 1):
    #     amatrix[:, i] = myelin_data**(i)
    #     bmatrix[:, i] = gradient_data**(i)
    # template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))
    # N_para = 2 * highest_order + 1   ##
    N_para = n_node

    # Setting hyper-parameters
    n_trial = validation_config.n_trial
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Fusion Heter Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 5 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w     = x_mass[0:
                            N_para, :]
        para_I     = x_mass[N_para:
                            2 * (N_para), :]
        para_G     = x_mass[2 * (N_para):
                            2 * (N_para) + 1, :]
        para_sigma = x_mass[2 * (N_para) + 1:
                            3 * (N_para) + 1, :]
        para_W_I   = x_mass[3 * (N_para) + 1:
                            4 * (N_para) + 1, :]
        para_W_G   = x_mass[4 * (N_para) + 1:
                            x_mass.shape[0], :]
        arx_mass   = np.concatenate(
            (para_w, para_I, 
             para_G,
             para_sigma,para_W_I, para_W_G), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_fusion(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))
            # print('Set ', i, ' Trial ', k, ' done.', flush=True)

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Fusion Heter Done', flush=True)

def CBIG_mfm_validation_main_neuro_para(set_range=range(1, 11),gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Neuro Para', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    highest_order = 1
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0]
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]
    amatrix = np.zeros((n_node, highest_order + 1))
    bmatrix = np.zeros((n_node, highest_order + 1))
    for i in range(highest_order + 1):
        amatrix[:, i] = myelin_data**(i)
        bmatrix[:, i] = gradient_data**(i)
    template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))
    N_para = 2 * highest_order + 1

    # Setting hyper-parameters
    n_trial = validation_config.n_trial
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Neuro Para Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 4 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w = template_mat @ x_mass[0:N_para, :]
        para_I = template_mat @ x_mass[N_para:
                                       2 * N_para, :]
        para_G = x_mass[2 * (N_para):
                        2 * (N_para) + 1, :]
        para_sigma = template_mat @ x_mass[2 * N_para + 1:
                                           3 * N_para + 1, :]
        para_W_I = template_mat @ x_mass[3 * N_para + 1:
                                         x_mass.shape[0], :]

        arx_mass = np.concatenate(
            (para_w, para_I, 
             para_G,
             para_sigma,para_W_I), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_neuro(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Neuro Para Done', flush=True)

def CBIG_mfm_validation_main_neuro_heter(set_range=range(1,11), gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Neuro Heter', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    n_node = system_config.n_roi
    # amatrix = np.zeros((n_node, highest_order + 1))
    # bmatrix = np.zeros((n_node, highest_order + 1))
    # for i in range(highest_order + 1):
    #     amatrix[:, i] = myelin_data**(i)
    #     bmatrix[:, i] = gradient_data**(i)
    # template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))
    # N_para = 2 * highest_order + 1   ##
    N_para = n_node

    # Setting hyper-parameters
    n_trial = validation_config.n_trial
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Neuro Heter Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 4 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w     = x_mass[0:
                            N_para, :]
        para_I     = x_mass[N_para:
                            2 * (N_para), :]
        para_G     = x_mass[2 * (N_para):
                            2 * (N_para) + 1, :]
        para_sigma = x_mass[2 * (N_para) + 1:
                            3 * (N_para) + 1, :]
        para_W_I   = x_mass[3 * (N_para) + 1:
        #                     4 * (N_para) + 1, :]
        # para_W_G   = x_mass[4 * (N_para) + 1:
                            x_mass.shape[0], :]
        arx_mass   = np.concatenate(
            (para_w, para_I, 
             para_G,
             para_sigma,para_W_I), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_neuro(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Neuro Heter Done', flush=True)

def CBIG_mfm_validation_main_fusion_para_wg_heter(set_range=range(1, 11),gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Fusion Para wg_heter', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    highest_order = 1
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0]
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = system_config.n_roi

    amatrix = np.zeros((n_node, highest_order + 1))
    bmatrix = np.zeros((n_node, highest_order + 1))
    for i in range(highest_order + 1):
        amatrix[:, i] = myelin_data**(i)
        bmatrix[:, i] = gradient_data**(i)
    template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))

    N_para = 2 * highest_order + 1

    # Setting hyper-parameters
    n_trial = validation_config.n_trial
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Fusion Para wg_heter Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 5 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w      = template_mat @ x_mass[0:
                                            N_para, :]
        para_I      = template_mat @ x_mass[N_para:
                                            2 * (N_para), :]
        para_G      =                x_mass[2 * (N_para):
                                            2 * (N_para) + 1, :]
        para_sigma  = template_mat @ x_mass[2 * (N_para) + 1:
                                            3 * (N_para) + 1, :]
        para_W_I    = template_mat @ x_mass[3 * (N_para) + 1:
                                            4 * (N_para) + 1, :]
        para_W_G    =                x_mass[4 * (N_para) + 1:
                                            x_mass.shape[0], :]
        arx_mass = np.concatenate(
            (para_w, para_I, 
             para_G,
             para_sigma,para_W_I, para_W_G), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_fusion(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Fusion Para wg_heter Done', flush=True)

def CBIG_mfm_validation_main_fusion_heter_gammag(set_range=range(1,11), gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Fusion Heter GammaG', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    n_node = system_config.n_roi
    # amatrix = np.zeros((n_node, highest_order + 1))
    # bmatrix = np.zeros((n_node, highest_order + 1))
    # for i in range(highest_order + 1):
    #     amatrix[:, i] = myelin_data**(i)
    #     bmatrix[:, i] = gradient_data**(i)
    # template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))
    # N_para = 2 * highest_order + 1   ##
    N_para = n_node

    # Setting hyper-parameters
    n_trial = validation_config.n_trial
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Fusion GammaG Heter Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 6 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w     = x_mass[0:
                            N_para, :]
        para_I     = x_mass[N_para:
                            2 * (N_para), :]
        para_G     = x_mass[2 * (N_para):
                            2 * (N_para) + 1, :]
        para_sigma = x_mass[2 * (N_para) + 1:
                            3 * (N_para) + 1, :]
        para_W_I   = x_mass[3 * (N_para) + 1:
                            4 * (N_para) + 1, :]
        para_W_G   = x_mass[4 * (N_para) + 1:
                            5 * (N_para) + 1, :]
        para_gamma_G   = x_mass[5 * (N_para) + 1:
                            x_mass.shape[0], :]
        arx_mass   = np.concatenate(
            (para_w, para_I, 
             para_G,
             para_sigma,para_W_I, para_W_G, para_gamma_G), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_fusion_gammag(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))
            # print('Set ', i, ' Trial ', k, ' done.', flush=True)

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Fusion Heter GammaG Done', flush=True)

def CBIG_mfm_validation_main_fusion_para_gammag(set_range=range(1, 11),gpu_index=0):
    '''
    This function is to validate the estimated parameters of mean field
    model.
    The objective function is the summation of FC correlation cost and
    FCD KS statistics cost.

    Args:
        gpu_index:      index of gpu used for optimization
    Returns:
        None
    '''
    print('Fusion Para GammaG', flush=True)
    # Setting GPU
    torch.cuda.set_device(gpu_index)

    # Create output folder
    input_path = system_config.output_path + training_config.output_dir
    output_path = system_config.output_path + validation_config.output_dir
    if not os.path.isdir(output_path):
        os.makedirs(output_path)

    # Loading myelin and gradient data
    highest_order = 1
    myelin_data = fc.csv_matrix_read(training_config.myelin_training)
    myelin_data = myelin_data[:, 0]
    gradient_data = fc.csv_matrix_read(training_config.RSFC_gradient_training)
    gradient_data = gradient_data[:, 0]
    n_node = myelin_data.shape[0]

    amatrix = np.zeros((n_node, highest_order + 1))
    bmatrix = np.zeros((n_node, highest_order + 1))
    for i in range(highest_order + 1):
        amatrix[:, i] = myelin_data**(i)
        bmatrix[:, i] = gradient_data**(i)
    template_mat = np.hstack((amatrix, bmatrix[:, 1:highest_order + 1]))

    N_para = 2 * highest_order + 1

    # Setting hyper-parameters
    n_trial = validation_config.n_trial  # 并行处理，500/n_trial个参数集模型同时跑验证
    vali_dup = 20

    for i in set_range:
        random_seed_cuda = i + 100
        torch.cuda.manual_seed(random_seed_cuda)

        load_file = ['random_initialization_', str(i), '.csv']
        load_path = [input_path] + load_file
        xmin = fc.csv_matrix_read(''.join(load_path))

        print('******** Fusion Para Validation Set: ', ''.join(load_file), flush=True)
        print('Time: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)

        x_nonzero = xmin[:, xmin[0, :] != 0]
        x_mass = x_nonzero[0:-3, :]

        result_save = np.zeros((6 + 6 * n_node + 1, x_nonzero.shape[1]))
        result_save[0:3, :] = x_nonzero[-3:, :]

        para_w = template_mat @ x_mass[0:N_para, :]
        para_I = template_mat @ x_mass[N_para:2 *
                                       (N_para), :]
        para_sigma = template_mat @ x_mass[2 * (N_para) +
                                           1:3 * (N_para) + 1, :]
        para_W_I = template_mat @ x_mass[3 * (N_para) +
                                           1:4 * (N_para) + 1, :]
        para_W_G = template_mat @ x_mass[4 * (N_para) +
                                           1:5 * (N_para) + 1, :]
        para_gamma_G    =          x_mass[5 * (N_para) + 
                                           1:x_mass.shape[0], :]
        arx_mass = np.concatenate(
            (para_w, para_I, x_mass[2 * (N_para):2 *
                                    (N_para) + 1, :],
             para_sigma,para_W_I, para_W_G, para_gamma_G), 0)

        result_save[6:, :] = arx_mass

        for k in range(n_trial):
            # print('Set ', i, ' Trial ', k, ' start')
            print('Set ', i, ' Trial ', k+1, '/', n_trial, flush=True)
            in_para = arx_mass[:, 50 * k:50 * (k + 1)]
            vali_total, vali_corr, vali_ks = \
                fc.CBIG_combined_cost_validation_fusion(
                    in_para, vali_dup)
            result_save[3, 50 * k:50 * (k + 1)] = vali_corr
            result_save[4, 50 * k:50 * (k + 1)] = vali_ks
            result_save[5, 50 * k:50 * (k + 1)] = vali_total
            # print('Set ', i, ' Trial ', k, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()))

        save_path = [output_path] + load_file
        np.savetxt(''.join(save_path), result_save, delimiter=',')

        print('Set ', i, ' done: ', time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()), flush=True)
        print('******************************************', flush=True)
    print('Fusion Para GammaG Done', flush=True)

def vali_main(plan_type):
    cases = {
    plan.neuro_heter: CBIG_mfm_validation_main_neuro_heter,
    plan.neuro_para: CBIG_mfm_validation_main_neuro_para,
    plan.fusion_heter: CBIG_mfm_validation_main_fusion_heter,
    plan.fusion_para: CBIG_mfm_validation_main_fusion_para,
    plan.fusion_para_wg_heter: CBIG_mfm_validation_main_fusion_para_wg_heter,
    plan.fusion_heter_gammag: CBIG_mfm_validation_main_fusion_heter_gammag,
    plan.fusion_para_gammag: CBIG_mfm_validation_main_fusion_para_gammag
    }
    return cases.get(plan_type, plan.fusion_heter)

if __name__ == '__main__':
    from pMFM_config import print_config
    print_config()
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    print(system_config.title, flush=True)

    plan_type = system_config.plan_type
    vali_main(plan_type)(set_range=system_config.vali_random_seeds)
