#!/bin/bash
# Description: 管理和运行多个train_vali.py任务的脚本
# Usage: ./run_mouse_train_vali.sh {start|start_custom|stop|stop_gpu|status|status_gpu|log|monitor|list|restart} [参数]
# 以不同的参数调用train_vali.py
# 以实现在Linux多卡环境下的多任务批量运行与管理

# 创建日志和PID目录
mkdir -p logs
mkdir -p pids

# 配置文件路径
CONFIG_FILE="mouse_task_config.conf"

# 函数：读取配置文件
read_config() {
    local config_file=$1
    local tasks=()
    
    if [ ! -f "$config_file" ]; then
        echo "错误: 配置文件 $config_file 不存在"
        return 1
    fi

    # 读取配置文件，忽略注释和空行
    while IFS=';' read -r gpu plan group fold seeds; do
        # 跳过空行和注释
        [[ -z "$gpu" || "$gpu" =~ ^# ]] && continue
        tasks+=("$gpu;$plan;$group;$fold;$seeds")
    done < "$config_file"
    
    printf '%s\n' "${tasks[@]}"
}

# 函数：生成任务唯一标识符
generate_task_id() {
    local gpu_index=$1
    local plan_type=$2
    local group=$3
    local fold=$4
    local seeds=$5
    
    # 将seeds中的逗号替换为下划线
    local seeds_clean=${seeds//,/_}
    
    # 生成任务ID：gpu -> plan -> group -> fold -> seeds
    echo "task_gpu${gpu_index}_plan${plan_type}_${group}_fold${fold}_seeds${seeds_clean}"
}

# 函数：启动单个任务
start_task() {
    local gpu_index=$1
    local plan_type=$2
    local group=$3
    local fold=$4
    local seeds=$5
    
    # 生成任务ID
    local task_id
    task_id=$(generate_task_id "$gpu_index" "$plan_type" "$group" "$fold" "$seeds")
    
    echo "启动任务: $task_id"

    # 启动任务
    nohup python -u train_vali.py --gpu "$gpu_index" --plan "$plan_type" --group "$group" --fold "$fold" --seeds "$seeds" > "logs/${task_id}.log" 2>&1 &
    
    # 保存PID
    echo $! > "pids/${task_id}.pid"
    echo "任务 $task_id 已启动，PID: $(cat "pids/${task_id}.pid")"
}

# # 函数：启动所有任务
# start_all() {
#     echo "启动所有任务..."
    
#     # 示例配置：可以根据需要修改这些配置数组
#     local gpu_list=(0 0 1 2)  # 可以指定不同任务使用哪个GPU
#     local plan_list=(4 4 4 4)
#     local group_list=("ctl" "exp" "ctl" "ctl")
#     local fold_list=(5 1 1 1)
#     local seeds_list=("3,4,5" "3,4,5" "3" "4,5")
    
#     # 检查数组长度是否一致
#     if [ ${#gpu_list[@]} -ne ${#plan_list[@]} ] || [ ${#gpu_list[@]} -ne ${#group_list[@]} ] || [ ${#gpu_list[@]} -ne ${#fold_list[@]} ] || [ ${#gpu_list[@]} -ne ${#seeds_list[@]} ]; then
#         echo "错误：配置数组长度不一致"
#         return 1
#     fi
    
#     for i in "${!gpu_list[@]}"; do
#         start_task "${gpu_list[i]}" "${plan_list[i]}" "${group_list[i]}" "${fold_list[i]}" "${seeds_list[i]}"
#         sleep 2  # 延迟避免冲突
#     done
    
#     echo "所有任务已在后台启动"
# }

# 函数：启动所有任务
start_all() {
    echo "从配置文件 $CONFIG_FILE 启动所有任务..."
    
    # 读取配置
    local tasks
    tasks=$(read_config "$CONFIG_FILE")
    if [ $? -ne 0 ]; then
        echo "无法读取配置文件"
        return 1
    fi
    # conda init
    # conda activate pMFM
    local task_count=0
    while IFS= read -r task_line; do
        [ -z "$task_line" ] && continue
        
        # 解析任务配置
        IFS=';' read -r gpu plan group fold seeds <<< "$task_line"
        
        echo "配置: GPU=$gpu, Plan=$plan, Group=$group, Fold=$fold, Seeds=$seeds"
        start_task "$gpu" "$plan" "$group" "$fold" "$seeds"
        ((task_count++))
        
        sleep 2  # 延迟避免冲突
    done <<< "$tasks"
    
    echo "已启动 $task_count 个任务"
}

# 函数：启动自定义任务
start_custom() {
    local gpu_index=$1
    local plan_type=$2
    local group=$3
    local fold=$4
    local seeds=$5
    
    if [ -z "$gpu_index" ] || [ -z "$plan_type" ] || [ -z "$group" ] || [ -z "$fold" ] || [ -z "$seeds" ]; then
        echo "用法: $0 start_custom <gpu_index> <plan_type> <group> <fold> <seeds>"
        echo "示例: $0 start_custom 0 4 ctl 1 1,2"
        return 1
    fi
    
    start_task "$gpu_index" "$plan_type" "$group" "$fold" "$seeds"
}

# 函数：停止指定任务
stop_task() {
    local task_id=$1
    
    if [ -z "$task_id" ]; then
        echo "需要指定任务ID"
        echo "可用任务ID:"
        for pid_file in pids/task_*.pid; do
            if [ -f "$pid_file" ]; then
                local id=$(basename "$pid_file" .pid | tr -d '\r')
                echo "  $id"
            fi
        done
        return 1
    fi
    
    # 同时检查普通文件名和带\r的文件名
    local pid_file_normal="pids/${task_id}.pid"
    local pid_file_with_cr="pids/${task_id}"$'\r'".pid"
    
    local actual_pid_file=""
    
    if [ -f "$pid_file_normal" ]; then
        actual_pid_file="$pid_file_normal"
    elif [ -f "$pid_file_with_cr" ]; then
        actual_pid_file="$pid_file_with_cr"
    else
        echo "任务 $task_id 的PID文件不存在"
        return 1
    fi
    
    # 原有的停止逻辑保持不变
    local pid
    pid=$(cat "$actual_pid_file")
    if kill -0 "$pid" 2>/dev/null; then
        echo "停止任务 $task_id (PID: $pid)"
        kill "$pid"
        rm "$actual_pid_file"
    else
        echo "任务 $task_id 进程 $pid 不存在"
        rm "$actual_pid_file"
    fi
}

# 函数：停止所有任务
stop_all() {
    echo "停止所有任务..."
    for pid_file in pids/task_*.pid; do
        if [ -f "$pid_file" ]; then
            local task_id=$(basename "$pid_file" .pid)
            local pid
            pid=$(cat "$pid_file")
            if kill -0 "$pid" 2>/dev/null; then
                echo "停止任务 $task_id (PID: $pid)"
                kill "$pid"
            fi
            rm "$pid_file"
        fi
    done
    # 额外清理
    pkill -f "train_vali.py" 2>/dev/null && echo "已清理残留进程"
}

# 函数：按GPU停止任务
stop_by_gpu() {
    local gpu_index=$1
    if [ -z "$gpu_index" ]; then
        echo "需要指定GPU索引"
        return 1
    fi
    
    echo "停止GPU $gpu_index 上的所有任务..."
    for pid_file in pids/task_gpu${gpu_index}_*.pid; do
        if [ -f "$pid_file" ]; then
            local task_id=$(basename "$pid_file" .pid)
            local pid
            pid=$(cat "$pid_file")
            if kill -0 "$pid" 2>/dev/null; then
                echo "停止任务 $task_id (PID: $pid)"
                kill "$pid"
            fi
            rm "$pid_file"
        fi
    done
}

# 函数：查看任务状态
status() {
    echo "=== 任务状态 ==="
    local found=0
    
    for pid_file in pids/task_*.pid; do
        if [ -f "$pid_file" ]; then
            found=1
            local task_id=$(basename "$pid_file" .pid)
            local pid
            pid=$(cat "$pid_file")
            if kill -0 "$pid" 2>/dev/null; then
                echo "✅ $task_id: 运行中 (PID: $pid)"
            else
                echo "❌ $task_id: 已停止 (PID: $pid) - 清理无效PID文件"
                rm "$pid_file"
            fi
        fi
    done
    
    if [ $found -eq 0 ]; then
        echo "没有找到任务记录"
    fi
    
    # 检查是否有未记录的进程
    local running_count
    running_count=$(pgrep -f "train_vali.py" | wc -l)
    if [ "$running_count" -gt 0 ]; then
        echo ""
        echo "发现 $running_count 个未记录的train_vali.py进程:"
        pgrep -f "train_vali.py" | xargs ps -o pid,cmd --no-headers
    fi
}

# 函数：按GPU查看任务状态
status_by_gpu() {
    local gpu_index=$1
    if [ -z "$gpu_index" ]; then
        echo "需要指定GPU索引"
        return 1
    fi
    
    echo "=== GPU $gpu_index 任务状态 ==="
    local found=0
    
    for pid_file in pids/task_gpu${gpu_index}_*.pid; do
        if [ -f "$pid_file" ]; then
            found=1
            local task_id=$(basename "$pid_file" .pid)
            local pid
            pid=$(cat "$pid_file")
            if kill -0 "$pid" 2>/dev/null; then
                echo "✅ $task_id: 运行中 (PID: $pid)"
            else
                echo "❌ $task_id: 已停止 (PID: $pid)"
            fi
        fi
    done
    
    if [ $found -eq 0 ]; then
        echo "GPU $gpu_index 上没有任务记录"
    fi
}

# 函数：查看配置文件
show_config() {
    echo "=== 配置文件内容 ==="
    if [ -f "$CONFIG_FILE" ]; then
        cat "$CONFIG_FILE"
    else
        echo "配置文件不存在"
    fi
}

# 函数：编辑配置文件  
edit_config() {
    if [ -z "$EDITOR" ]; then
        EDITOR="vi"
    fi
    "$EDITOR" "$CONFIG_FILE"
}

# 函数：查看任务日志
show_log() {
    local task_id=$1
    local lines=${2:-10}  # 默认显示最后10行
    
    if [ -z "$task_id" ]; then
        echo "需要指定任务ID"
        echo "可用任务ID:"
        for pid_file in pids/task_*.pid; do
            if [ -f "$pid_file" ]; then
                local id=$(basename "$pid_file" .pid)
                echo "  $id"
            fi
        done
        return 1
    fi
    
    local log_file="logs/${task_id}.log"
    if [ -f "$log_file" ]; then
        echo "=== 任务 $task_id 日志最后 ${lines} 行 ==="
        tail -n "$lines" "$log_file"
    else
        echo "任务 $task_id 的日志文件不存在: $log_file"
    fi
}

# 函数：实时监控任务日志
monitor_log() {
    local task_id=$1
    
    if [ -z "$task_id" ]; then
        echo "需要指定任务ID"
        return 1
    fi
    
    local log_file="logs/${task_id}.log"
    if [ -f "$log_file" ]; then
        echo "开始实时监控任务 $task_id 日志 (Ctrl+C 退出)"
        tail -f "$log_file"
    else
        echo "任务 $task_id 的日志文件不存在: $log_file"
    fi
}

# 函数：列出所有任务
list_tasks() {
    echo "=== 所有任务列表 ==="
    for pid_file in pids/task_*.pid; do
        if [ -f "$pid_file" ]; then
            local task_id=$(basename "$pid_file" .pid)
            # 解析任务ID获取信息
            local gpu=$(echo "$task_id" | grep -oE 'gpu[0-9]+' | sed 's/gpu//')
            local plan=$(echo "$task_id" | grep -oE 'plan[0-9]+' | sed 's/plan//')
            local group=$(echo "$task_id" | cut -d'_' -f3)
            local fold=$(echo "$task_id" | grep -oE 'fold[0-9]+' | sed 's/fold//')
            local seeds=$(echo "$task_id" | grep -oE 'seeds[0-9_]+' | sed 's/seeds//' | tr '_' ',')
            
            local pid
            pid=$(cat "$pid_file")
            local status="❌"
            if kill -0 "$pid" 2>/dev/null; then
                status="✅"
            fi
            
            echo "$status GPU$gpu | Plan: $plan | Group: $group | Fold: $fold | Seeds: $seeds"
            echo "   任务ID: $task_id (PID: $pid)"
            echo ""
        fi
    done
}

# 函数：重启单个任务
restart_single_task() {
    local task_id=$1
    
    # 检查任务是否存在
    local pid_file="pids/${task_id}.pid"
    if [ ! -f "$pid_file" ]; then
        echo "任务 $task_id 不存在"
        return 1
    fi
    
    # 从任务ID解析参数
    local gpu=$(echo "$task_id" | grep -oE 'gpu[0-9]+' | sed 's/gpu//')
    local plan=$(echo "$task_id" | grep -oE 'plan[0-9]+' | sed 's/plan//')
    local group=$(echo "$task_id" | cut -d'_' -f3)
    local fold=$(echo "$task_id" | grep -oE 'fold[0-9]+' | sed 's/fold//')
    local seeds=$(echo "$task_id" | grep -oE 'seeds[0-9_]+' | sed 's/seeds//' | tr '_' ',')
    
    # 停止原任务
    stop_task "$task_id"
    sleep 2
    
    # 重新启动
    start_task "$gpu" "$plan" "$group" "$fold" "$seeds"
}

# 函数：检查所有任务进度
check_progress() {
    local lines=${1:-6}  # 默认显示最后6行
    local lines=${1:-6}  # 默认显示最后6行
    
    echo "=== 任务进度检查（每个日志最后 ${lines} 行）==="
    
    # 检查logs目录是否存在
    if [ ! -d "logs" ]; then
        echo "日志目录不存在"
        return 1
    fi
    
    # 检查是否有日志文件
    local log_files=(logs/task_*.log)
    if [ ${#log_files[@]} -eq 0 ]; then
        echo "没有找到任务日志文件"
        return 1
    fi
    
    # 按文件名排序，确保顺序一致
    IFS=$'\n' sorted_log_files=($(sort <<<"${log_files[*]}"))
    unset IFS
    
    for log_file in "${sorted_log_files[@]}"; do
        if [ -f "$log_file" ]; then
            local task_id=$(basename "$log_file" .log)
            echo ""
            echo "=== 任务: $task_id ==="
            echo "日志文件: $log_file"
            echo "最后 ${lines} 行内容:"
            echo "----------------------------------------"
            tail -n "$lines" "$log_file"
            echo "----------------------------------------"
        fi
    done
    
    echo ""
    echo "进度检查完成，共检查 ${#log_files[@]} 个任务日志"
}

# 主程序逻辑
case "$1" in
    start)
        start_all
        ;;
    start_custom)
        start_custom "$2" "$3" "$4" "$5" "$6"
        ;;
    stop)
        if [ -n "$2" ]; then
            stop_task "$2"
        else
            stop_all
        fi
        ;;
    stop_gpu)
        stop_by_gpu "$2"
        ;;
    status)
        status
        ;;
    status_gpu)
        status_by_gpu "$2"
        ;;
    config)
        show_config
        ;;
    edit_config)
        edit_config
        ;;
    log)
        show_log "$2" "$3"
        ;;
    monitor)
        monitor_log "$2"
        ;;
    list)
        list_tasks
        ;;
    restart)
        if [ -n "$2" ]; then
            # 使用函数处理单个任务重启
            restart_single_task "$2"
        else
            stop_all
            sleep 3
            start_all
        fi
        ;;
    progress)  # 新增进度检查命令
        if [ -n "$2" ]; then
            check_progress "$2"
        else
            check_progress 6  # 默认显示6行
        fi
        ;;
    *)
        echo "给脚本执行权限: chmod +x mouse_task_run.sh"
        echo "用法: $0 {start|start_custom|stop|stop_gpu|status|status_gpu|log|monitor|list|restart} [参数]"
        echo ""
        echo "命令说明:"
        echo "  start                        启动预设的所有任务"
        echo "  start_custom <g> <p> <gr> <f> <s> 启动自定义任务"
        echo "                                参数: g=GPU索引, p=plan类型, gr=组名, f=fold数, s=种子列表"
        echo "  stop [task_id]               停止所有任务或指定任务"
        echo "  stop_gpu <gpu_index>         停止指定GPU上的所有任务"
        echo "  status                       查看所有任务状态"
        echo "  status_gpu <gpu_index>       查看指定GPU上的任务状态"
        echo "  config                       查看当前配置文件内容"
        echo "  edit_config                  编辑配置文件"
        echo "  log <task_id> [行数]         查看指定任务日志"
        echo "  monitor <task_id>            实时监控指定任务日志"
        echo "  list                         列出所有任务详细信息"
        echo "  restart [task_id]            重启所有任务或指定任务"
        echo "  progress [行数]              检查所有任务进度(显示每个日志最后N行,默认6行)"
        echo ""
        echo "示例:"
        echo "  $0 start                                     启动预设任务"
        echo "  $0 start_custom 0 4 ctl 1 1,2               启动自定义任务"
        echo "  $0 stop task_gpu0_plan4_ctl_fold1_seeds1_2  停止指定任务"
        echo "  $0 stop_gpu 0                                停止GPU 0上所有任务"
        echo "  $0 status                                    查看所有任务状态"
        echo "  $0 list                                      列出所有任务"
        echo "  $0 log task_gpu0_plan4_ctl_fold1_seeds1_2   查看任务日志"
        echo "  $0 progress                   查看所有任务日志最后6行"
        exit 1
        ;;
esac