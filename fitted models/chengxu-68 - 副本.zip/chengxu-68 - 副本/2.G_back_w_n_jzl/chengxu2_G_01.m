%=======================================================================================
% 2.68个脑区，使用全局缩放因子+反馈神经血管偶联
%=======================================================================================

for global_i = 1:10
    
tic

filename = 'nc';   % File name to store the output datae

NR = 68;  % Number of regions

% load SC;  % Load structural connectivity
N2 = NR * NR;

MAX_GEN = 60;   % Maximal number of generations (iterations) for the genetic algorithm
FUN_TOL = 1e-3;  % Functional tolerance



% % Lower and Upper bound for the model parameters
% % 血流动力学
% MAX_V = 2;
% MIN_V = 0;
% MAX_Q = 2;
% MIN_Q = 0;

% 偶联
MIN_f  = 0.8;
MAX_f  = 2;

% Recurrent excitation
MIN_Wee  = 2;
MAX_Wee  = 4;

% Recurrent inhibition
MIN_Wie  = 2;
MAX_Wie  = 4;

% Inter-regional EC
MIN_gc =  -2;
MAX_gc =   2;

% External input
MIN_Spi = 0.2;
MAX_Spi = 0.4;

% Creat lower and upper bounds in vector form
MIN_WEE  = MIN_Wee*ones(1, NR);
MAX_WEE  = MAX_Wee*ones(1, NR);

MIN_WIE  = MIN_Wie*ones(1, NR);
MAX_WIE  = MAX_Wie*ones(1, NR);

MIN_F  = MIN_f*ones(1, NR);
MAX_F  = MAX_f*ones(1, NR);

% MIN_GC = MIN_gc*ones(1,N2);  % N2 is the number of inter-regional EC parameters
% MAX_GC = MAX_gc*ones(1,N2);
MIN_GC = MIN_gc;  % N2 is the number of inter-regional EC parameters
MAX_GC = MAX_gc;

MIN_SPI = MIN_Spi;
MAX_SPI = MAX_Spi;

% lb = [MIN_WEE MIN_WIE MIN_GC MIN_SPI MIN_V MIN_Q]; 
% ub = [MAX_WEE MAX_WIE MAX_GC MAX_SPI MAX_V MAX_Q]; 
% lb = [MIN_WEE MIN_WIE MIN_GC MIN_SPI]; 
% ub = [MAX_WEE MAX_WIE MAX_GC MAX_SPI]; 
lb = [MIN_WEE MIN_WIE MIN_GC MIN_SPI MIN_F]; 
ub = [MAX_WEE MAX_WIE MAX_GC MAX_SPI MAX_F]; 

NP = length(lb);  % number of parameters to be estimated

% Set optimization parameters


% Use this option if run in a local computer ,'PopulationSize',1
 opts = optimoptions('ga', 'MaxGenerations', MAX_GEN,'PopulationSize',100, 'FunctionTolerance', FUN_TOL, ...
     'UseParallel',true, 'Display','iter','PlotFcn', @gaplotbestf);

% Use this option if run in a cluster 
%opts = optimoptions('ga', 'MaxGenerations', MAX_GEN, 'FunctionTolerance', FUN_TOL, ...
%    'UseParallel',true, 'Display','iter');

% Call the ga function to estimate the parameters
[x,fval,eflag,outpt, population, scores,bestfitness,perbestIndividua] = ga(@FCobj, NP,...
    [],[],[],[],lb,ub,[],opts);


disp('The optimal solution is:');
x
fval

disp('The maximal correlation is:');
f = -FCobj(x)

% Save the output data
fullpath = mfilename('fullpath'); 
[path,name]=fileparts(fullpath);
save (['out/out' name(1,size(name,2) - 1:size(name,2)) '/' filename mat2str(global_i) '.mat'], 'x', 'fval', 'eflag', 'outpt', 'population', 'scores','bestfitness','perbestIndividua','CroFraction');

% poolobj = gcp('nocreate');
% delete(poolobj);

disp('Program completed!');

toc

clc;
close all;
clear all;
% exit;
end

%==========================================================================
%           Objective Function
%==========================================================================

function f = FCobj(x)

NR = 68;   % Number of ROIs

filelist = ['sub003';'sub005';'sub009';'sub020';'sub021';'sub023';'sub024';'sub027';'sub030';'sub033';'sub034';
    'sub035';'sub036';'sub054';'sub063';'sub065';'sub067';'sub072';'sub073';'sub077';'sub080';'sub081';'sub083';
    'sub089';'sub091';'sub103';'sub104';'sub107';'sub109';'sub110';'sub113';'sub114';'sub115'];
fullpath = mfilename('fullpath'); 
[path,name]=fileparts(fullpath);
filename2 = ['../input/jzl_fc/ROICorrelation_ROISignal_' filelist(str2double(name(1,size(name,2) - 1:size(name,2))) ,:) '.mat'];
load(filename2);
fc_train = ROICorrelation;


EFC  = fc_train;

% Vectorize the upper part of the FC matrix (since it is symmetric matrix)
UEFC = triu(EFC, 1);
VEFC = UEFC(:);
VEFC(VEFC==0)=[]; 

% load SC;             % Structural connectivity
% SCM = NET2_SC;       % SC of the EXE-LIM network

filename1 = ['../input/jzl_sc/' filelist(str2double(name(1,size(name,2) - 1:size(name,2))) ,:) '/dk_nums.csv'];
load(filename1);
sc_train = dk_nums;
SCM = sc_train / max(max(sc_train)) ;

N2 = NR*NR;
 

Flag_Noise = 1;      % Introduce noise to the neural model
Flag_Mean_BOLD = 0;  % If 1: Remove the mean of the neural activity before inputing to the Hemodynamic model


DT = 10e-3;   % 10 ms; Integration step 
ST = 200;     % Total simulation time in sec

TR  = 2;      % Scan interval (2 sec)
NTR = TR/DT; 

TFC = 20;     % Start time to calculate simulated FC
NFC = TFC/DT;

W_EI0 = 3.0;  % Fixed weight from excitaotry neural population to inhibitory neural population 

% Vectorize the parameters
Wei = W_EI0*ones(NR, 1);
Wee = x(1:NR);   
Wie = x(NR+1:2*NR);
Wgc = x(2*NR+1);
SPI = x(2*NR+2);
couple_f = x(end - NR + 1 :end);
% v_estimate = x(end-1);
% q_estimate = x(end);

% GC = zeros(NR,NR);

m = 1;

% for i=1:NR
%     for j=1:NR
%        
% %        if (MAP2(i,j)==1)
%            GC(i,j) = Wgc(m);
%            m = m+1;
% %        end      
%         
%     end  
% end
GC = Wgc;

t1=clock;

% Call the function "Model_NEURAL" to calculate the neural activity
[t, X] = Model_NEURAL2_G(NR, DT, ST, SCM, GC, Wee, Wei, Wie, SPI, Flag_Noise);
t2=clock;
time1 = etime(t2,t1)

[tt, BOLD] = Model_HEMO(NR, DT, ST, X, Flag_Mean_BOLD,couple_f);

t3=clock;
time2 = etime(t3,t2)

SBOLD = BOLD(NFC:NTR:end, :);  % Downsample the BOLD signals

SFC = corrcoef(SBOLD);    % Simulated FC

% Vectorize the upper part of the simulated FC matrix (since it is symmetric matrix)
USFC = triu(SFC, 1);
VSFC = USFC(:);
VSFC(VSFC==0)=[]; 

% Pearson's correlation between the empirical FC and simulated FC
CO = corrcoef(VEFC, VSFC);
COF = CO(1,2);

t4=clock;
time3 = etime(t4,t3)

% Value of the objective function to be minimized
f = -COF;


end


