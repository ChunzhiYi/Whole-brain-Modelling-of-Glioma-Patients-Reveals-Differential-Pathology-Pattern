
% Compute the BOLD signals in all ROIs sequentially 

function [tt, BOLD] = Model_HEMO(N, dt, ST, XX, FLAG_Mean_BOLD,F) 

global NR; 

% Hemodynamic model
global kappa;
global gamma;
global tau_hemo;
global alpha;
global rho;
global V0;

global couple_f;

couple_f = F;


NR = N; % Number of brain regions

Tend= ST;  % Sec
DT = dt;   % Integration step (sec)

% Local parameters

kappa = 0.65;  % 
gamma = 0.41;  % 

tau_hemo = 0.98;  % Sec
alpha = 0.32;

rho = 0.34;  %
V0 = 0.02;

s0 = 0;
f0 = 1.0;
v0 = 1.0;
q0 = 1.0;

k1 = 7*rho;
k2 = 2;  
k3 = 2*rho-0.2;


NE = 4;  % Number of equations

%=================================== 
%     Hemodynamic model
%=================================== 

BOLD = zeros(Tend / DT + 1,NR);

for i = 1:NR
  E = XX(:,i);
  I = XX(:,i+NR);
  EI = (2/3)*E + (1/3)*I;
  
  if (FLAG_Mean_BOLD==1)
    XM = mean(EI);
    EI = EI - XM;
  end
  
  X0 = [s0 f0 v0 q0];
  X = X0;
  
%   tt = [];
%   yy = [];
  tt = zeros(1,Tend / DT + 1);
  yy = zeros(Tend / DT + 1,NE);

  t = 0;
  count = 1;

%   while (t<=Tend) 
%     
%     tt = [tt t];
%     yy = [yy; X]; 
%     Z = EI(count);
%     
%     X = RK2(NE, DT, t,X, Z); 
%     t = t+DT;
%     count = count + 1;
%   end
  
  for ii = 1 : Tend / DT + 1
    tt(1,ii) = t;
    yy(ii,:) = X; 
    Z = EI(count);
    
    X = RK2(NE, DT, t,X, Z,i); 
    t = t+DT;
    count = count + 1;
  end

  S  = yy(:,1);
  F  = yy(:,2);
  V  = yy(:,3);
  Q  = yy(:,4);
  


  BOLD(:,i) = V0*( k1*(1-Q) + k2*(1-Q./V) + k3*(1-V) );

end




end




%=======================================================================
%       Fourth-order Runge-Kutta [RK(4)] method (Hemodynamic Model)
%=======================================================================

function y = RK2(n, h, t, y, z,n_doi)
  h_half = h/2; 
  s = zeros(1,n);
  yk = zeros(1,n);
    
  %========================
  f = HEMO(t, y, z,n_doi);
  s = f;
  
  %========================
    
  tk = t + h_half;
  yk = y + h_half*f;
  f = HEMO(tk, yk, z,n_doi);
  s = s + 2*f;
  
  %========================
   
  yk = y + h_half*f;
  f = HEMO(tk, yk, z,n_doi);
  s = s + 2*f;
  
 %========================
  
  tk = t + h;
  yk = y + h*f;  
  f = HEMO(tk, yk, z,n_doi);
  
%========================

  y = y + h/6*(s+f);
  
  
  
end




%==============================================
%              Hemo-dynamics
%==============================================

function dS=HEMO(t,XS, Z,n_doi)

global kappa;
global gamma;
global tau_hemo;
global alpha;
global rho;
% global v_estimate;
% global q_estimate;
global couple_f;
s=XS(1);
f=XS(2);
v=XS(3);
q=XS(4);

dsdt = Z - kappa*(s) - gamma*(f-1);
dfdt = couple_f(n_doi)*s;

% dsdt = Z - 0.6*s;
% dfdt = couple_f(n_doi)*s - 0.6*(f - 1);


dvdt = 1/tau_hemo*( f - v^(1/alpha));                     
dqdt = 1/tau_hemo*( f*OE(f, rho)/rho - v^(1/alpha)*q/v);  
% dvdt = 1/tau_hemo*( f - v^(1/alpha) + v_estimate);                      % 3.22 加入 v_estimate
% dqdt = 1/tau_hemo*( f*OE(f, rho)/rho - v^(1/alpha)*q/v + q_estimate);   % 3.22 加入 q_estimate

dS=[dsdt dfdt dvdt dqdt];
   
end


function y=OE(flow, rho)

y = 1-(1-rho)^(1/flow);

end










