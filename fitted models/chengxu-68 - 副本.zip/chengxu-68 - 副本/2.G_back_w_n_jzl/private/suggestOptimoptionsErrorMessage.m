function suggestOptimoptionsErrorMessage(arg, invalidParamNameId, linkDestination)
%SUGGESTOPTIMOPTIONS Throw error message to use optimoptions function

%   Copyright 2018-2019 The MathWorks, Inc.

if feature('hotlinks') && ~isdeployed
    % Create explicit char array so as to avoid translation
    openTag = sprintf('<a href = "matlab: helpview(''gads'',''%s'');">',...
        linkDestination);
    closeTag = '</a>';
    linkStr = getString(message('globaloptim:suggestOptimoptionsErrorMessage:LinkToOptimOptionsTable'));
    taggedString = [openTag linkStr closeTag];
else
    taggedString = '';
end

errMsg = getString(message(invalidParamNameId, arg, taggedString));

% Throw error
throwAsCaller(MException(invalidParamNameId, errMsg))
