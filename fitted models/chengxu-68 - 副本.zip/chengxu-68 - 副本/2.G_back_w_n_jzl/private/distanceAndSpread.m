function [distance_std, spread] = distanceAndSpread(Distance,Rank,score,score_old)
%distanceAndSpread Calculate average distance and spread of a population
%   distanceAndSpread is private to GAMULTIOBJ

%   Copyright 2007-2019 The MathWorks, Inc.


% Get individual and their distance measure from first front
distance = Distance((Rank == 1));
% Remove infinite distances
distance = distance(isfinite(distance));
if ~isempty(distance)
    num_solution = length(distance);
    distance_mean = sum(distance)/num_solution;
    distance_std = norm(distance - distance_mean)/sqrt(num_solution);
else
    distance_mean = 0;
    distance_std = 0; % All solutions are at extreme
end

[~,index] = min(score,[],1);
extremeParetoSol_new = score(index,:);

[~,index] = min(score_old,[],1);
extremeParetoSol_old = score_old(index,:);

% Calculate average distance between extreme solution
extremeParetoDistance = 0;
for i = 1:size(extremeParetoSol_new,1)
    extremeParetoDistance = extremeParetoDistance + norm((extremeParetoSol_old(i,:) - extremeParetoSol_new(i,:)));
end

if ~isfinite(extremeParetoDistance)
   extremeParetoDistance = 0; 
end
% Calculate spread of the non-dominated front
if size(extremeParetoSol_new,2) > 1 && (extremeParetoDistance > 0 ...
        || distance_std > 0)
    spread = (extremeParetoDistance + distance_std)/ ...
        (extremeParetoDistance + size(extremeParetoSol_new,2)*distance_mean);
else
    spread =  extremeParetoDistance;
end
