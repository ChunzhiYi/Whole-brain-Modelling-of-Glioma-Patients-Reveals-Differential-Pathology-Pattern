function state = stepgamultiobj(subpopIndex,thisPopulation,options,state, ...
    GenomeLength,FitnessFcn,ConstrFcn)
%STEPGAMULTIOBJ perform one step using a variant of NSGA-II algorithm
%   This function is private to GAMULTIOBJ.

%   Copyright 2007-2019 The MathWorks, Inc.

popSize     = size(state.Population(thisPopulation,:),1);
population  = state.Population(thisPopulation,:);
C           = state.C(thisPopulation,:);
Ceq         = state.Ceq(thisPopulation,:);
isFeas      = state.isFeas(thisPopulation,:);
maxLinInfeas = state.maxLinInfeas(thisPopulation,:);
score       = state.Score(thisPopulation,:); 
rank        = state.Rank(thisPopulation,:);
Distance    = state.Distance(thisPopulation,:);
score_old   = score;
numObj = size(score,2);

% How many crossover offspring will there be from each source?
nXoverKids = round(options.CrossoverFraction * popSize);
nMutateKids = popSize - nXoverKids;
% how many parents will we need to complete the population?
nParents = 2 * nXoverKids + nMutateKids;


% Selection.
parents = feval(options.SelectionFcn,[-rank,Distance],nParents,options,options.SelectionFcnArgs{:});
% Shuffle to prevent locality effects. 
parents = parents(randperm(length(parents)));

% Everyones parents are stored here for genealogy display
state.Selection = [parents'];

% Here we make all of the members of the next generation
xoverKids  = feval(options.CrossoverFcn,parents(1:(2 * nXoverKids)),options,GenomeLength, ...
    FitnessFcn,score,population,options.CrossoverFcnArgs{:});
mutateKids = feval(options.MutationFcn,parents((1 + 2 * nXoverKids):end),options,GenomeLength, ...
    FitnessFcn,state,score,population,options.MutationFcnArgs{:});

% Group them into the next generation
nextPopulation = [xoverKids ; mutateKids ];

% Score the population (unique individuals). Using a double cache is ideal
% but using unique for now which is available in MATLAB
if state.HaveDuplicates
    % Uses 1e-12 as absolute tolerance to detect dups
    DS = max(abs(nextPopulation),[],1);
    tol = 1e-12;
   [pop,IA,IC] = uniquetol(nextPopulation,tol, 'DataScale',DS,'ByRows',true);   
else
    pop = nextPopulation;
end

% Evaluate the population
if isfield(options,'LinearConstr') && options.LinearConstr.linconCheck
    [nextIsFeas,nextMaxLinInfeas] = isTrialFeasible(pop,options.LinearConstr.Aineq, ...
        options.LinearConstr.bineq,options.LinearConstr.Aeq,options.LinearConstr.beq, ...
        options.LinearConstr.lb,options.LinearConstr.ub,options.TolCon);
else
    nextIsFeas = true(size(pop,1),1);
    nextMaxLinInfeas = zeros(size(pop,1),1);
end


if strcmpi(options.Vectorized, 'off')
    % Score remaining members of the population
        [nextScore,nextC,nextCeq,nextIsFeas] = objAndConVectorizer(pop, ...
            FitnessFcn,ConstrFcn,numObj,state.mIneq,state.mEq,options.SerialUserFcn, ...
            nextIsFeas,options.TolCon);    
else
    if state.mAll > 0
        [nextC,nextCeq] = ConstrFcn(pop);
        % Make sure sizes of empties are correct
        if state.mEq == 0
            nextCeq = reshape(nextCeq,size(nextC,1),0);
        elseif state.mIneq == 0
            nextC = reshape(nextC,size(nextCeq,1),0);
        end        
        nextIsFeas = nextIsFeas & isNonlinearFeasible(nextC,nextCeq,options.TolCon);
    else
        nextC = zeros(size(pop,1),0);
        nextCeq = zeros(size(pop,1),0);
    end
    
    % Only evaluate feasible points
    nextScore = Inf(size(pop,1),numObj);
    nextScore(nextIsFeas,:) = FitnessFcn(pop(nextIsFeas,:));
end

% Update function evaluation counter
state.FunEval = state.FunEval + size(nextScore,1);

% Verify if we have duplicates in the popultaion and turn off the flag for
% dup evaluation in future.
if state.HaveDuplicates
    nextScore = nextScore(IC,:);
    nextC = nextC(IC,:);
    nextCeq = nextCeq(IC,:);
    nextIsFeas = nextIsFeas(IC,:);
    nextMaxLinInfeas = nextMaxLinInfeas(IC,:);
    % Check if we still have dups
    state.HaveDuplicates = numel(IA) ~= numel(IC);
end

%--Prepare for next generation--

% Combine new and old population
population   = [population;   nextPopulation];
score        = [score;        nextScore];
C            = [C;            nextC];
Ceq          = [Ceq;          nextCeq];
isFeas       = [isFeas;       nextIsFeas];
maxLinInfeas = [maxLinInfeas; nextMaxLinInfeas];

% Sort combined population and pick best 'popSize' individuals for next
% generation
[state.Population(thisPopulation,:),state.Score(thisPopulation,:), ...
    state.Rank(thisPopulation,:),state.Distance(thisPopulation,:), ...
    state.C(thisPopulation,:),state.Ceq(thisPopulation,:), ...
    state.isFeas(thisPopulation,:),state.maxLinInfeas(thisPopulation,:),...
    state.complexWarningThrown] = ...
        rankAndDistance(population,score,C,Ceq,isFeas,maxLinInfeas,...
        options,popSize, state.complexWarningThrown);

% Calculate average distance and spread for the Pareto front
[state.AverageDistance(subpopIndex), state.Spread(state.Generation+1,subpopIndex)] = ...
    distanceAndSpread(state.Distance(thisPopulation,:),state.Rank(thisPopulation,:), ...
    state.Score(thisPopulation,:),score_old);

